import tkinter as tk
import tkinter.ttk as ttk

class CheckboxList(ttk.Frame):
    '''
    Organized list of checkbuttons with retrievable statuses
    according to `picks` that are comprised of `text` labels
    and `key` keys
    '''

    def __init__(self, parent=None, title = None, picks=[], sticky = 'W', default = 0):
      
        ttk.Frame.__init__(self, parent)
        self.vars = {}
        self.hidden = 0
        self.title = None
        
        title_offset = 0
        if title is not None:
            title_offset = 1
            self.title = tk.Label(
                self,
                text = title
            )
            self.title.grid(column=0, row=0)

        for i, choice in enumerate(picks):
        
            var = tk.IntVar()
            var.set(default)
            chk = ttk.Checkbutton(self, text=choice['text'], variable=var)
            chk.grid(column=0, row=title_offset+i, pady=5, sticky = sticky)
            self.vars[choice['key']] = var
            
        return
    
    
    def status(self):
        
        vals = {k: v.get() for k,v in self.vars.items()}
        return vals
    
    
    def display(self, active):
        
        if not active:
            self.grid_remove()
        else:
            self.grid()
        