import subprocess
import csv
import time

import argparse
import json
import os
import re
import sys
import tempfile

import tkinter
from tkinter import *
from tkinter import filedialog
from tkinter import messagebox
from tkinter import ttk

# SOME FIXED VALUES
CRED_CONFIG_PATH = '.m360config'
LAST_RUN_PATH = '.last-run'
DB_HOSTNAME = 'vpwprddwvi01.miscny.nyenet'
DB_DATABASE = 'VPDW'

# TODO: Maybe add log file for each run

class intro_screen:
    def __init__(self, rootWin):
        # Import the graphics data to identify what views to be included in the checkbox window
        self.import_graphics_data()
        # Set the ttk style options for various widgets
        style = ttk.Style()
        style.configure('my.TMenubutton', font = ('Helvetica', 10), background = "#FFFFFF")
        style.configure('my.TButton', font = ('Helvetica', 13))
        style.configure('my.TCheckbutton', font = ('Helvetica', 13))
        self.rootWin = rootWin

        # Read user credentials if stored
        self.username = StringVar()
        self.pw = StringVar()

        credpath = os.path.join(
            os.path.expanduser('~'),
            CRED_CONFIG_PATH
        )

        if os.path.isfile(credpath):

            with open(credpath, 'rb') as f:

                creds = json.load(f)

                if 'USERNAME' in creds:
                    self.username.set(creds['USERNAME'])

                if 'PASSWORD' in creds:
                    self.pw.set(creds['PASSWORD'])

                if 'HOSTNAME' in creds:
                    DB_HOSTNAME = creds['HOSTNAME']

                if 'DATABASE' in creds:
                    DB_DATABASE = creds['DATABASE']

        # Read M360 Configuration
        try:
            self.read_config()
        except:
            print('Loading configuration failed. Make sure to set via settings.')
            self.r_location = ''
            self.python_location = 'python'
            self.folder_location = ''
            
        # Read parameters from last run, if available
        # (and re-use)
        self.cohort = StringVar()
        self.comparison_table = StringVar()
        self.report = StringVar()
        self.desc = StringVar()
        self.year = StringVar()
        self.dual_indicator = StringVar()
        self.comparison_description = StringVar()
        
        self.dual_indicator_options = [
            "Non-Dual",
            "Dual",
            "Both (Separate Reports)",
        ]
        
        self.year_options = [
            "2017", 
            "2018", 
            "2019",
            "2020",
            "2021",
        ]
        
        lastrunpath = os.path.join(self.folder_location, LAST_RUN_PATH)
        if os.path.isfile(lastrunpath):
            
            with open(lastrunpath, 'rb') as f:
                
                loaded = False
                try:
                    params = json.load(f)
                    loaded = True
                except:
                    pass
            
                if loaded:
                    # Carefully attempt to load saved settings,
                    # falling back on some sane default it the load
                    # crashes (probably because the key was not saved
                    # last time the report was run)
                    saved_options = [
                        ('DESC', 'desc', ''),
                        ('REPORT', 'report', ''),
                        ('COHORT', 'cohort', ''),
                        ('YEAR', 'year', self.year_options[-1]),
                        ('COMPARISON_TABLE', 'comparison_table', ''),
                        ('DUAL_INDICATOR', 'dual_indicator', self.dual_indicator_options[0]),
                        ('COMPARISON_DESCRIPTION', 'comparison_description', ''),
                    ]
                    
                    for opt in saved_options:
                        try:
                            getattr(self, opt[1]).set(params[opt[0]])
                        except:
                            getattr(self, opt[1]).set(opt[2])
        
        # Initialize context (with tables)
        self.context = {}

        with open('tables.json', 'rt') as f:
            self.context = json.load(f)

        # Initialize, then hide all views, only showing the main window
        self.build_views()

    def read_config(self):
        with open('config.json', 'rb') as f:
            config = json.load(f)

        self.r_location = config['R_CMD']
        self.python_location = config['PYTHON_CMD']
        self.folder_location = config['M360_FOLDER']


    def build_views(self):
        # Build the other windows
        self.build_settings()
        self.build_selection()
        self.build_intro()
        self.build_welcome()


    def build_intro(self):

        rootWin.columnconfigure(0, weight = 1)
        rootWin.columnconfigure(1, weight = 3)
        rootWin.columnconfigure(2, weight = 0)
        rootWin.columnconfigure(3, weight = 1)
        rootWin.columnconfigure(4, weight = 3)

        boldStyle = ttk.Style()
        boldStyle.configure(
            "Bold.TButton",
            font = ("Arial", 12, "bold"),
        )

        # This is the main window to input information
        # Banner message
        self.banner = Label(
            rootWin,
            text = "Set Member360 Report Parameters",
            font = ("Helvetica", 14, "bold"),
        )
        self.banner.grid(row = 0, column = 0, columnspan = 5)

        # Cohort Table
        self.cohort_label = Label(rootWin, text = "Cohort Table")
        self.cohort_label.grid(row = 1, column = 0)
        self.cohort_entry = ttk.Entry(rootWin, textvariable = self.cohort, width = 30)
        self.cohort_entry.grid(row = 1, column = 1)

        self.salient_button_cohort = ttk.Button(
            rootWin,
            text = "\u2191",
            command = lambda: self.build_upload('Cohort'),
            style = 'Bold.TButton',
            width = 3,
        )
        self.salient_button_cohort.grid(row = 1, column = 2)

        self.desc_label = Label(rootWin, text = "Cohort Description")
        self.desc_label.grid(row = 1, column = 3)
        self.desc_entry = ttk.Entry(rootWin, textvariable = self.desc)
        self.desc_entry.grid(row = 1, column = 4)

        # # Show/Hide comparison configuration
        self.comparison_on = tkinter.IntVar(value=0)
        self.comparison_toggle = ttk.Checkbutton(
            rootWin,
            var = self.comparison_on,
            onvalue = 1,
            offvalue = 0,
            command=self.toggle_comparison_options,
        )
        self.comparison_toggle.grid(row = 2, column = 2)

        Label(
            rootWin,
            text = "Select Custom Comparison Cohort (Leave Unchecked for Statewide)",
            font = ("Helvetica", 8, "italic"),
        ).grid(row = 2, column = 0, columnspan = 2)
        
        # Show/Hide section listing
        self.exclude_on = tkinter.IntVar(value=0)
        self.exclude_toggle = ttk.Checkbutton(
            rootWin,
            var = self.exclude_on,
            command=self.toggle_exclude,
        ).grid(row=2, column=4)
        
        Label(
            rootWin,
            text = 'Exclude Certain Views',
            font = ('Helvetica', 8, 'italic'),
        ).grid(row = 2, column = 3)
        
        # Comparison Table
        self.comparison_label = Label(rootWin, text = "Comparison Table")
        self.comparison_label.grid(row = 3, column = 0)
        self.comparison_entry = ttk.Entry(rootWin, textvariable = self.comparison_table)
        self.comparison_entry.grid(row = 3, column = 1)
        
        self.salient_button_comparison = ttk.Button(
            rootWin,
            text = "\u2191",
            command = lambda: self.build_upload('Comparison'),
            style = 'Bold.TButton',
            width = 3,
        )
        self.salient_button_comparison.grid(row = 3, column = 2)
        
        self.comparison_description_label = Label(rootWin, text = "Comparison Description")
        self.comparison_description_label.grid(row = 3, column = 3)
        self.comparison_description_entry = ttk.Entry(rootWin, textvariable = self.comparison_description)
        self.comparison_description_entry.grid(row = 3, column = 4)

        self.year_label = Label(rootWin, text = "Year")
        self.year_label.grid(row = 4, column = 0)        
        self.year_menu = ttk.OptionMenu(rootWin, self.year, "", *self.year_options, style='my.TMenubutton')
        self.year_menu["menu"].configure(bg="#FFFFFF")
        self.year_menu.grid(row = 4, column = 1)

        # Dual
        self.dual_label = Label(rootWin, text = "Dual Eligibility")
        self.dual_label.grid(row = 4, column = 3)
        self.dual_menu = ttk.OptionMenu(
            rootWin,
            self.dual_indicator,
            self.dual_indicator.get(),
            *self.dual_indicator_options,
            style='my.TMenubutton',
        )
        self.dual_menu["menu"].configure(bg="#FFFFFF")
        self.dual_menu.grid(row = 4, column = 4)

        # Report Name
        self.report_label = Label(rootWin, text = "Report Name")
        self.report_label.grid(row = 5, column = 0)
        self.report_entry = ttk.Entry(rootWin, textvariable = self.report)
        self.report_entry.grid(row = 5, column = 1)

        # Customize views / selection checkbox
        self.choose_views = IntVar()
        self.choose_views.set(0)
        selectview = components.CheckboxList(
            rootWin,
            title='View Selection',
            picks=[{'key': x[0], 'text': f'Section {x[0]}: {x[1]}'} for x in self.sec_data],
            default = 1,
        )
        selectview.grid(column=6, row=1, rowspan=6)
        self.selectview = selectview

        # Settings button
        self.back_button = ttk.Button(rootWin, text = "Back", command = self.intro_back, style = 'my.TButton')
        self.back_button.grid(row = 6, column = 0, columnspan = 2)

        # Next button
        self.next_button = ttk.Button(rootWin, text = "Next", command = self.click_next, style = 'my.TButton')
        self.next_button.grid(row = 6, column = 3, columnspan = 2)

        # Left-align all widgets and pad equally
        for child in rootWin.winfo_children():
            if hasattr(child, 'grid_configure'):
                child.grid_configure(padx = 5, pady = 5, sticky = 'W')

        # Re-Align Header
        self.banner.grid_configure(columnspan = 5, sticky = 'EW')

        # Re-Align Toggle Checkbox
        self.comparison_toggle.grid_configure(sticky = 'E')

        # Re-Align Buttons
        self.back_button.grid_configure(sticky = 'EW')
        self.next_button.grid_configure(sticky = 'EW')

        # Width adjustments across the columns
        for widget in [
            self.comparison_entry,
            self.report_entry,
            self.desc_entry,
            self.comparison_description_entry,
        ]:
            widget.configure(width = 30)

        for widget in [
            self.year_menu,
            self.dual_menu
        ]:
            widget.configure(width = 25)

        self.toggle_comparison_options()
        self.toggle_exclude()

        rootWin.protocol("WM_DELETE_WINDOW", self.on_exit)
        rootWin.withdraw()

    def toggle_comparison_options(self):
        ''' Shows and hides the comparison cohort selections '''

        toggle = self.comparison_on.get()

        elements = [
            self.comparison_label,
            self.comparison_entry,
            self.comparison_description_label,
            self.comparison_description_entry,
            self.salient_button_comparison,
        ]

        if toggle == 0:
            for element in elements:
                element.grid_remove()

            self.comparison_table.set('')
            self.comparison_description.set('')

        else:
            for element in elements:
                element.grid()
    
    def toggle_exclude(self):
        toggle = self.exclude_on.get()
        self.selectview.display(toggle)

    def intro_back(self):
        rootWin.withdraw()
        self.welcomeWin.deiconify()

    def build_upload(self, group = 'Cohort'):
        # This window is used for the Salient upload tool
        # Open a file dialog to select an excel file
        self.rootWin.attributes("-topmost", 0)
        self.uploadWin = Toplevel()
        self.uploadWin.title("CIN Upload")
        self.uploadWin.attributes("-topmost", 1)
        self.uploadWin.tk.call('wm', 'iconphoto', self.uploadWin._w, PhotoImage(file="assets/m360_icon.png"))
        # Header
        Label(self.uploadWin, text = f"Upload a Salient CIN list to Member360 ({group} Table)", anchor = 'w').grid(row = 0, column = 0, columnspan = 2, pady = 5, padx = 5)
        # Button for upload
        ttk.Button(self.uploadWin, text = "Choose File", command = self.salient_choose_file, width = 20, style = 'my.TButton').grid(row = 1, column = 0, pady = 5, padx = 5)
        self.salient_location = StringVar()
        self.upload_file_entry = ttk.Entry(self.uploadWin, textvariable = self.salient_location, width = 80).grid(row = 1, column = 1, pady = 5, padx = 5)
        # Set the table name
        Label(self.uploadWin, text = "Table Name (No Spaces)", width = 20).grid(row = 2, column = 0, pady = 5, padx = 5)
        self.upload_table = StringVar()
        self.upload_table_entry = ttk.Entry(self.uploadWin, textvariable = self.upload_table, width = 80).grid(row = 2, column = 1, pady = 5, padx = 5)
        Label(self.uploadWin, text = "", width = 45).grid(row = 3, column = 0, columnspan = 2, pady = 5, padx = 5)
        # Navigation buttons
        ttk.Button(self.uploadWin, text = "Back", command = self.salient_go_back, width = 10, style = 'my.TButton').grid(row = 4, column = 0, pady = 5, padx = 5)
        ttk.Button(self.uploadWin, text = "Upload", command = lambda x: self.salient_upload(group), width = 20, style = 'my.TButton').grid(row = 4, column = 1, pady = 5, padx = 5)

    def salient_choose_file(self):
        # Function to open the system file open/close dialog
        self.uploadWin.attributes("-topmost", 0)
        self.salient_location.set(filedialog.askopenfilename())
        self.uploadWin.attributes("-topmost", 1)

    def salient_upload(self, group = 'Cohort'):
        # Some basic error handling to throw the exception if any errors occur during the upload
        file_location = self.salient_location.get()
        table_location = self.upload_table.get()

        if messagebox.askyesno('Upload', 'Upload: '+file_location+' ? \nNote you need to have entered your HPDW credentials on the main page.\nUploading will overwrite the ' + table_location + ' table.'):

            try:
                ## Check filetype
                if len(file_location) >= 4 and file_location[-4:] == '.csv':
                    data = pd.read_csv(file_location, header=None, dtype=str)
                elif len(file_location) >= 5 and file_location[-5:] == '.xlsx':
                    data = pd.read_excel(file_location, header=None, engine='openpyxl', dtype=str)
                else:
                    raise Exception("Not a .csv or .xlsx extract")

                df = data.iloc[:, [0]].copy()
                df.columns = ["CIN"]
                df = df[pd.notnull(df.CIN)].copy()
                df = df[df.CIN.str.match('^[A-Za-z0-9]{8}$')].copy()
                df = df[~df.duplicated()].copy()

                if df.shape[0] == 0:
                    raise Exception("No valid CINs in first column of submitted file. Are they 8 character alpha-numeric?")

                # Write out just the CIN list as CSV
                df.to_csv('assets/Salient_CINs.csv', index = False)

                # Upload the CIN list we just wrote to CSV
                DBCONN = get_connection(self.username.get(), self.pw.get(), DB_HOSTNAME, 5433, DB_DATABASE)

                clean_query = "DROP TABLE IF EXISTS " + table_location + ";"
                init_table_query = "CREATE TABLE " + table_location + "(CIN VARCHAR(256));"
                upload_table_query = "COPY " + table_location + " FROM LOCAL 'assets/Salient_CINs.csv' PARSER fcsvparser(type='traditional', delimiter=',');"

                query_db(DBCONN, clean_query, False)
                query_db(DBCONN, init_table_query, False)
                query_db(DBCONN, upload_table_query, False)

                messagebox.showinfo('Success', 'File has been successfully uploaded to ' + table_location + f' ({df.shape[0]} unique CINs)')
                
                if group == 'Cohort':
                    self.cohort.set(table_location)
                else:
                    self.comparison_table.set(table_location)
                    
                DBCONN.close()

            except Exception as e:
                messagebox.showerror("Error", f"{e}")
            finally:
                if os.path.exists('assets/Salient_CINs.csv'):
                    os.remove('assets/Salient_CINs.csv')
        else:
            # Do nothing
            1+1
        self.rootWin.attributes("-topmost", 1)

    def salient_go_back(self):
        # Function to go back to the main win from the Salient upload window
        self.uploadWin.withdraw()

    def build_welcome(self):
        self.welcomeWin = Toplevel()
        self.welcomeWin.title("Member360")
        self.welcomeWin.attributes("-topmost",1)
        self.welcomeWin.tk.call('wm', 'iconphoto', self.welcomeWin._w, PhotoImage(file = "assets/m360_icon.png")) 

        # This is the main window to input information
        # Banner message
        self.welcomeBanner = Label(
            self.welcomeWin,
            text = "Welcome to Member360",
            font = ("Helvetica", 14, "bold"),
        )
        self.welcomeBanner.grid(row = 0, column = 0, columnspan = 5)
        
        #Blank Row
        Label(self.welcomeWin, text = "Please enter your VPDW credentials", anchor = 'w', width = 50).grid(row = 1, column = 0, columnspan = 2, pady = 5, padx = 5)    
    
       # Username
        self.username_label = Label(self.welcomeWin, text = "VPDW Username", width = 18, anchor = 'w')
        self.username_label.grid(row = 2, column = 0)
        self.username_entry = ttk.Entry(self.welcomeWin, textvariable = self.username)
        self.username_entry.grid(row = 2, column = 1)
        self.username_entry.focus_set()

        # Password
        self.pw_label = Label(self.welcomeWin, text = "VPDW Password", width = 18, anchor = 'w')
        self.pw_label.grid(row = 3, column = 0)

        self.pw_entry = ttk.Entry(self.welcomeWin, textvariable = self.pw, show = "*")
        self.pw_entry.grid(row = 3, column = 1)    
    
        # Settings button
        self.settings_button = ttk.Button(self.welcomeWin, text = "Settings", command = self.click_settings, style = 'my.TButton')
        self.settings_button.grid(row = 4, column = 0, columnspan = 2)

        # Next button
        self.next_button = ttk.Button(self.welcomeWin, text = "Next", command = self.welcome_next, style = 'my.TButton')
        self.next_button.grid(row = 4, column = 1, columnspan = 2)
    
        # Left-align all widgets and pad equally
        for child in self.welcomeWin.winfo_children():
            if hasattr(child, 'grid_configure'):
                child.grid_configure(padx = 5, pady = 5, sticky = 'W')

        # Re-Align Header
        self.welcomeBanner.grid_configure(columnspan = 5, sticky = 'EW')    
    
        # Set the behavior when you click the x button
        self.welcomeWin.protocol("WM_DELETE_WINDOW", self.on_exit)
        #self.welcomeWin.withdraw()

    def check_table_access(self):
        ''' Confirm the user has SELECT access to requisite tables
        '''
        
        table_status = []
        try:
            DBCONN = get_connection(self.username.get(), self.pw.get(), DB_HOSTNAME, 5433, DB_DATABASE)
            selectable_tables = query_db(DBCONN, 'spec_table_check', True, {'uid': self.username.get()})
            DBCONN.close()
        except:
            return table_status
            
        selectable_tables = selectable_tables['table_name'].tolist()
        
        for k, v in self.context.items():
            if len(k) > 4 and k[:4] == 'TBL_':
                table_status.append((v, v.upper() in selectable_tables,))
        
        return table_status

    
    def retrieve_year_data(self, refresh=True):
        ''' Retrieve year data from SQL, caching it for future speedup if in novalidate mode
        '''
        
        if refresh or (not os.path.isfile('.year_cache')):
            DBCONN = get_connection(self.username.get(), self.pw.get(), DB_HOSTNAME, 5433, DB_DATABASE)
            years_available = query_db(DBCONN, "spec_year_check", True, self.context)
            DBCONN.close()
            
            years_available['label'] = (
                years_available['START_DATE'].dt.strftime('%b %Y') +
                ' - ' +
                years_available['END_DATE'].dt.strftime('%b %Y')
            )
            
            years_available = years_available.sort_values('YEAR_TYPE')
            years_available[['START_DATE', 'END_DATE']] = years_available[['START_DATE', 'END_DATE']].apply(lambda x: x.dt.strftime('%Y-%m-%d'))
            
            years_available.to_json('.year_cache')
        else:
            years_available = pd.read_json('.year_cache')
            
        return years_available


    def welcome_next(self):
    
        # Run year test query
        # Click next on the main window, test user credentials and get available years

        # Check to make sure all variables have values
        if self.username.get() != "" and self.pw.get() != "":

            self.welcomeWin.withdraw()
               
            try:

                ## Missing table check - using grants
                tables = self.check_table_access()
                missing_tables = [t for t,v in tables if not v]
                if len(missing_tables) > 0 and (not args.ignoremissing):
                    raise Exception('Missing table permissions on: ' + ', '.join(missing_tables))
                
                self.years_available = self.retrieve_year_data(refresh = not args.novalidate)
                self.year_menu['menu'].delete(0, 'end')
                
                ## Iterate over year types, adding a menu header with
                ## the options beneath it
                def create_menu_segment(header, entries):
                    self.year_menu['menu'].add_command(label = header, state = 'disabled')
                    for entry in entries['label'].tolist():
                        self.year_menu['menu'].add_command(label = entry, command=lambda v=entry: self.year.set(v))
                    
                for ytp in ['CY', 'FFY', 'SFY']:
                    create_menu_segment(ytp, self.years_available[self.years_available.YEAR_TYPE.str.startswith(ytp, na=False)])
                
                ## Other Rolling Years
                create_menu_segment('All Other Periods', self.years_available[pd.isnull(self.years_available.YEAR_TYPE)])

                #Open inputs window
                rootWin.deiconify()

            # If we have any problems, go back to the first window
            except Exception as e:
                messagebox.showwarning(
                    "Error",
                    f"Cohort Test Query Failed. Please check inputs.\n\n{e}"
                )
                self.welcomeWin.deiconify()
                
        else:
            messagebox.showwarning("Error", "Fill in all fields before continuing")
            self.welcomeWin.deiconify()

    def build_settings(self):
        # Build then hide the settings window
        self.settingsWin = Toplevel()
        self.settingsWin.title("Settings")
        self.settingsWin.attributes("-topmost", 1) # Keeps the window on top of everything else (need to fix)
        self.settingsWin.tk.call('wm', 'iconphoto', self.settingsWin._w, PhotoImage(file="assets/m360_icon.png")) # Set the window icon


        # Blank row
        Label(self.settingsWin, text = "Configure Inputs to Member360", anchor = 'w', width = 30).grid(row = 0, column = 0, columnspan = 2, pady = 5, padx = 5)

        # Choose output folder
        self.folder_button = ttk.Button(self.settingsWin, text = "Set the M360 Folder", command = self.choose_directory, width = 25, style = 'my.TButton')
        self.folder_button.grid(row = 2, column = 0, pady = 5, padx = 5)
        self.folder_location_label = Label(self.settingsWin, text = self.folder_location, width = 80, bg = "white", anchor = 'w')
        self.folder_location_label.grid(row = 2, column = 1, pady = 5, padx = 5)


        # Choose R location
        self.r_button = ttk.Button(self.settingsWin, text = "Set RScript.exe Location", command = self.choose_r, width = 25, style = 'my.TButton')
        self.r_button.grid(row = 3, column = 0, pady = 5, padx = 5)
        self.r_location_label = Label(self.settingsWin, text = self.r_location, width = 80, bg = "white", anchor = 'w')
        self.r_location_label.grid(row = 3, column = 1, pady = 5, padx = 5)

        # Blank row
        Label(self.settingsWin, text = "", anchor = 'w', width = 30).grid(row = 5, column = 0, columnspan = 2, pady = 5, padx = 5)

        # Test
        self.test_install = ttk.Button(self.settingsWin, text = "Run Installation", command = self.run_install, width = 15, style = 'my.TButton')
        self.test_install.grid(row = 6, column = 1, pady = 5, padx = 5)

        # Go Back
        ttk.Button(self.settingsWin, text = "Back", command = self.settings_exit, width = 15, style = 'my.TButton').grid(row = 6, column = 0, pady = 5, padx = 5)

        # Set the behavior when you click the x button
        self.settingsWin.protocol("WM_DELETE_WINDOW", self.settings_exit)
        self.settingsWin.withdraw()

    def settings_exit(self):
        # Function to close the settings window
        # also saves settings
        self.update_config_bat()
        self.settingsWin.withdraw()
        self.welcomeWin.deiconify()

    def on_exit(self):
        # When you click to exit (the window X button), this function is called
        if messagebox.askyesno("Exit", "Do you want to quit the application?"):
            self.rootWin.destroy()


    def click_settings(self):
        # Make the settings window appear when you click the settings button from the main window
        self.settingsWin.deiconify()

    def choose_directory(self):
        # Set the location of the M360 working directory
        self.settingsWin.attributes("-topmost", 0)
        self.folder_location_dialog = filedialog.askdirectory()
        self.folder_location_label.configure(text = self.folder_location_dialog)
        self.settingsWin.attributes("-topmost", 1)

    def choose_r(self):
        # Set the location of the RScript.exe file
        self.settingsWin.attributes("-topmost", 0)
        self.r_location_dialog = filedialog.askopenfilename()
        self.r_location_label.configure(text = self.r_location_dialog)
        self.settingsWin.attributes("-topmost", 1)

    def update_config_bat(self):

        if hasattr(self, 'r_location_dialog'):
            self.r_location = self.r_location_dialog
        if hasattr(self, 'folder_location_dialog'):
            self.folder_location = self.folder_location_dialog

        with open('config.json', 'wt') as f:
            json.dump({
                "PYTHON_CMD": self.python_location,
                "R_CMD": self.r_location,
                "M360_FOLDER": self.folder_location
            }, f)

    def run_install(self):
        self.update_config_bat()

        # Run the installation bat file
        self.settingsWin.attributes("-topmost", 0)

        # Install Required R Packages
        subprocess.call([self.r_location, f'{self.folder_location}/R_installation.R'])

        self.settingsWin.attributes("-topmost", 1)

    def click_next(self):
        # Click next on the main window, test the inputs the user entered
        # Check to make sure all variables have values
        

        if self.username.get() != "" and self.pw.get() != "" and self.cohort.get() != "" and self.report.get() != "":

            rootWin.withdraw()
            
            selected = self.years_available[self.years_available['label'] == self.year.get()]

            self.start_date = selected['START_DATE'].astype(str).values[0]
            self.end_date = selected['END_DATE'].astype(str).values[0]
            self.msr_yr = selected['MSR_YR'].astype(str).values[0]
            self.cdm_source = selected['CDM_SOURCE'].astype(str).values[0]

            self.TBL_MSR_RESULT = self.context['TBL_MSR_RESULT_CY'] if self.cdm_source == 'CY' else self.context['TBL_MSR_RESULT_RY']
            self.TBL_MSR_ELIG = self.context['TBL_MSR_ELIG_CY'] if self.cdm_source == 'CY' else self.context['TBL_MSR_ELIG_RY']

            # Option overrides:
            # if the comparison table is unset, do not allow a description for it
            if self.comparison_table.get() == '':
                self.comparison_description.set('')

            # Test our input parameters
            # assuming the user has not passed --novalidate argument (power users)
            if args.novalidate:
                self.final_window()
                return
                
            try:
                DBCONN = get_connection(self.username.get(), self.pw.get(), DB_HOSTNAME, 5433, DB_DATABASE)

                local_context = {'input_table': self.cohort.get(), 'start_date':self.start_date, 'end_date':self.end_date}
                local_context = {**local_context, **self.context}
                
                if 'comparison_table' in self.get_context():
                    local_context['comparison_table'] = self.get_context()['comparison_table']

                cohort_statistics = query_db(DBCONN, "spec_cohort_stats", True, local_context)
                self.cohort_statistics = cohort_statistics.to_dict('records')[0]
                
                pd.DataFrame(self.fig_data).rename(columns = {0:'figures', 1:'names'})['figures'].to_csv('assets/test_views.csv', header=True, index = False)
                self.final_window()
                
                # # Check to see if the checkbox was checked
                # if self.choose_views.get() == 0:
                    # # Add a check to make sure there are nonzero rows in the CIN table - maybe?
                    # # Write out the full list of views
                    # pd.DataFrame(self.fig_data).rename(columns = {0:'figures', 1:'names'})['figures'].to_csv('assets/test_views.csv', header=True, index = False)
                    # self.final_window()
                # else:
                    # self.selection_window()

            # If we have any problems, go back to the first window 
            except Exception as e:
                messagebox.showwarning(
                    "Error",
                    f"Cohort Test Query Failed. Please check inputs.\n\n{e}"
                )
                rootWin.deiconify()
        else:
            messagebox.showwarning("Error", "Fill in all fields before continuing")


    def selection_window(self):
        # Make the view selection window appear
        self.selectWin.deiconify()

    def build_selection(self):
        # Build the checkbox selection window for choosing views to include
        self.selectWin = Toplevel()
        self.selectWin.title("Custom View Selection")
        self.clMouseUpEvent = False
        Label(self.selectWin, text = "Choose a Custom Selection of Views to Include", anchor = "w").pack(pady = 5, padx = 5)
        ## self.makeCheckList() # Build the actual checklist
        self.selectWin.protocol("WM_DELETE_WINDOW", self.on_exit)
        self.selectWin.tk.call('wm', 'iconphoto', self.selectWin._w, PhotoImage(file="assets/m360_icon.png"))
        self.selectWin.withdraw()

    def import_graphics_data(self):
        # Open our config file, and read in the section / figure information
        with open("graphics_config.json", "r") as view_catalog:
            
            lines = json.load(view_catalog)

        # Generate a list of lists of the figures
        self.fig_data =[]
        for line in lines:
            self.fig_data.append([line["secind"] + "." + line["figind"], line["title"]])

        # Generate a list of lists of the sections
        self.sec_data = []
        for line in lines:
            a_row = [line["secind"], line["section"]]
            if a_row not in self.sec_data:
                self.sec_data.append(a_row)

    def checkListClicked(self, event):
        # Helper function for the checklist to make sure check/uncheck only activates on the mouse up part of the click
        self.clMouseUpEvent = True

    def browseEvent(self, itemID):
        # Disable hovering to change things
        if self.clMouseUpEvent:
            if self.cl.getstatus(itemID) == 'off':
                status = 'on'
            else:
                status = 'off'
            self.setChildrenStatus(itemID, status)
            self.clMouseUpEvent = False
        #print(self.cl.getselection())

    def setChildrenStatus(self, itemID, status):
        # Helper function to enable the parent checking/unchecking children views
        self.cl.setstatus(itemID, status)
        for childID in self.cl.hlist.info_children(itemID):
            self.setChildrenStatus(childID, status)

    def makeCheckList(self):
        self.cl = ttk.CheckList(self.selectWin, browsecmd=self.selectItem, width = 800, height = 600)
        self.cl.pack(pady = 5, padx = 5)
        # Generate the sections
        for section in self.sec_data:
            self.cl.hlist.add(section[0], text = section[1])
            self.cl.setstatus(section[0], "on") # Set the default status to checked
        # Generate the figures
        for figure in self.fig_data:
            self.cl.hlist.add(figure[0], text = figure[1])
            self.cl.setstatus(figure[0], "on") # Set the default status to checked

        self.cl.hlist.config(bg='white', selectbackground='white', selectforeground='black', header=True, browsecmd=self.browseEvent)
        self.cl.hlist.bind("<Button-1>", self.checkListClicked) # Bind the event to the mouse click
        self.cl.autosetmode()

        button_frame = Frame(self.selectWin)
        # Navigation buttons
        ttk.Button(button_frame, text = "Back", command = self.sel_go_back, style = 'my.TButton').pack(side = LEFT, pady = 5, padx = 5)
        ttk.Button(button_frame, text = "Next", command = self.go_next, style = 'my.TButton').pack(side = LEFT, pady = 5, padx = 5)
        button_frame.pack(pady = 5, padx = 5)

    def sel_go_back(self):
        # Go back to the main menu from the selection window
        self.selectWin.withdraw()
        rootWin.deiconify()

    def view_info(self):
        # Open the example views file
        subprocess.Popen(["assets\M360_Example.pdf"],shell=True)

    def go_next(self):
        # Write out our list of selected figures, excluding the section headers
        #print(self.cl.getselection())
        fig_list = pd.DataFrame(self.cl.getselection()).rename(columns = {0:'figures'})
        fig_list = fig_list[fig_list['figures'].str.contains('\.')]
        fig_list.to_csv('assets/test_views.csv', index = False)

        self.selectWin.withdraw()
        self.final_window()

    def selectItem(self, item):
        print(item, self.cl.getstatus(item))
        print(self.cl.getselection())

    def final_window(self):
        # Store parameters
        if os.path.exists(self.folder_location):
            
            with open(os.path.join(self.folder_location, LAST_RUN_PATH), 'wt') as f:
            
                json.dump({
                    'COHORT': self.cohort.get(),
                    'REPORT': self.report.get(),
                    'COMPARISON_TABLE': self.comparison_table.get(),
                    'DUAL_INDICATOR': self.dual_indicator.get(),
                    'COMPARISON_DESCRIPTION': self.comparison_description.get(),
                    'DESC': self.desc.get(),
                    'YEAR': self.year.get(),
                }, f)

        # Read out the inputs to the user before executing M360
        self.input_width = min(50,max(len(self.username.get()), len(self.cohort.get()), len(self.report.get()), len(self.desc.get()), len(self.year.get()))) + 5
        self.input_width = 20
        self.finalWin = Toplevel()
        self.finalWin.title("Confirm Inputs")
        self.finalWin.protocol("WM_DELETE_WINDOW", self.on_exit)
        self.finalWin.tk.call('wm', 'iconphoto', self.finalWin._w, PhotoImage(file="assets/m360_icon.png"))

        # if self.choose_views.get() == 0:
            # view_text = "All Selected"
        # else:
            # view_text = "Custom Selection"

        # [(Text,), (Columnspan,)]
        rows = [
            [("Confirm Inputs", None), (3,None)],
            [("Username", self.username.get()), (1,2)],
            [("Cohort Table", self.cohort.get()), (1,2)],
            [("Cohort Description", self.desc.get()), (1,2)],
            [("Comparison Table", self.comparison_table.get()), (1,2)] if self.comparison_table.get() != '' else [],
            [("Comparison Description", self.comparison_description.get()), (1,2)] if self.comparison_description.get() != '' else [],
            [("Report Name", self.report.get()), (1,2)],
            [("Year", self.year.get()), (1,2)],
            [("Dual Eligibility", self.dual_indicator.get()), (1,2)]
            # ,
            # [("Selected Views", view_text), (1,2)]
        ]
        
        rows = [row for row in rows if row != []]

        if not args.novalidate:

            # Submitted, eligible, and percent displays
            x = self.cohort_statistics["N_SUBMITTED"]
            y = self.cohort_statistics["N_WITH_ELIG_TCC"]
            z = y/x

            rows += [
                [("Member CINs Submitted", "{:,d}".format(x)), (2,1)],
                [("Member CINs with Eligibility + TCC", "{:,d} ({:.0%})".format(y, z)), (2,1)]
            ]

        for i, row in enumerate(rows):

            Label(self.finalWin, text=row[0][0], anchor="w", width=self.input_width*row[1][0]).grid(row=i, column=0, pady=5, padx=5, sticky="w", columnspan=row[1][0])

            if row[0][1] is None:
                continue

            Label(self.finalWin, text=row[0][1], anchor="w", bg="white", width=self.input_width*row[1][1]).grid(row=i, column=1, pady=5, padx=5, columnspan=row[1][0], sticky="e")

        # Blank row
        Label(self.finalWin, text = "").grid(row = len(rows) + 1, column = 0)

        
        # Back button
        ttk.Button(self.finalWin, text = "Back", command = self.go_back, width = 10, style = 'my.TButton').grid(row = len(rows)+3, column = 0, pady = 5, padx = 5)
        ttk.Button(self.finalWin, text = "Run", command = self.run_m360, width = 10, style = 'my.TButton').grid(row = len(rows)+3, column = 1, pady = 5, padx = 5)

    def go_back_summarywin(self):
        self.summaryWin.withdraw()
        rootWin.deiconify()

    def go_back(self):
        # If the user didn't decide to select views, go back to main window
        if(self.choose_views.get() == 0):
            self.finalWin.withdraw()
            rootWin.deiconify()

        # If the user did decide to select views, go back to page 2
        else:
            self.finalWin.withdraw()
            self.selectWin.deiconify()

    def get_context(self):
        ''' Returns context given user entries & table.json defaults '''

        context = {
            'uid': self.username.get(),
            'pwd': self.pw.get(),
            'cohort_name': 'Cohort',
            'comparison_name': 'Comparison',
            'end_date': self.end_date,
            'start_date': self.start_date,
            'msr_yr': self.msr_yr,
            'cdm_source': self.cdm_source,
            'TBL_MSR_RESULT': self.TBL_MSR_RESULT,
            'TBL_MSR_ELIG': self.TBL_MSR_ELIG,
            'cohort_table': self.cohort.get(),
            'report_name': re.sub('[^a-zA-Z0-9_]','',self.report.get()),
            'dual_ind': self.dual_indicator.get(),
            'comparison_description': self.comparison_description.get(),
            'debug': args.debug,
        }
        
        comparison_table = self.comparison_table.get()
        if comparison_table != '':
            context['comparison_table'] = comparison_table
        else:
            context['comparison_name'] = 'Statewide'

        return {**self.context, **context}

    def analyze_and_render(self, dual_ind = 0):
        
        dual_text = 'Dual' if dual_ind == 1 else 'Non-Dual'
        base_context = self.get_context()
        base_context['dual_ind'] = dual_ind
        base_context['report_name'] += f'_{dual_text}'
        
        # Analysis is conducted by rendering the R file
        # and having R run it
        if 'analysis' not in args.skip:
        
            base_status = f"Running analysis / graphics creation script ({dual_text})..."
            
            print(base_status, flush=True, end='\r')
            query_context = load_queries_into_context(base_context)
            analysis_context = {**query_context, **base_context}
            analysis_context['db_hostname'] = DB_HOSTNAME
            analysis_context['db_database'] = DB_DATABASE

            analysis_render = render_template('m360_analysis.R', context=analysis_context, searchpath='./')

            # If you've opted to save the render, it will store it helpfully
            # nearby the original m360_analysis.R file
            if args.saverender or args.renderonly:

                if not os.path.exists('render'):
                    os.mkdir('render')

                for queryname, querytext in query_context.items():
                    with open(f'render/{queryname}.render.sql', 'wt') as f:
                        f.write(querytext)

                with open(f'render/m360_analysis_{dual_text}.render.R', 'wt') as f:
                    f.write(analysis_render)
                    print(''.join([' ' for i in range(len(base_status))]), end='\r')
                    print('Saved render of analysis.R, continuing analysis...')

                if args.renderonly:
                    print('Terminating after rendering (--render-only).')
                    return


            with tempfile.NamedTemporaryFile(mode='wt', suffix='.R', delete=False) as t:

                renderfilename = t.name

                t.write(analysis_render)
                proc = subprocess.Popen(
                    f'{self.r_location} {t.name}',
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    bufsize=1
                )
                
                # Poll the process to figure out what it's
                # saying--currently this just consumes the
                # "Section [X] Complete" messages
                #
                # If debugging, dump output--otherwise only print
                # selected output in fancy style...
                total_sections = 8
                if args.debug:
                    while proc.poll() is None:
                        line, err = proc.communicate()
                        print(line, err)
                else:
                    for line in proc.stdout:
                        m = re.match('Section (\d) Complete', line)
                        if m is not None:
                            print(f'{base_status} [{m.group(1)}/{total_sections}]', end='\r', flush=True)

            # Clean temporary file
            os.unlink(renderfilename)

            print(f"{base_status} Done!", flush=True)


        print(f"Begin report construction ({dual_text})...", flush=True, end='')
        comparison_description = base_context['comparison_description']
        if comparison_description == '' and 'comparison_table' in base_context:
            comparison_description = f'No description provided ({base_context["comparison_table"]}).'
        
        generate_report(
            cohort_name=self.report.get(),
            cohort_description=self.desc.get(),
            time_period=f'{self.year.get()}',
            report_name=base_context['report_name'],
            dual_label='Non-Dual' if base_context['dual_ind'] == 0 else 'Dual',
            comparison_description=comparison_description,
            included_sections = [k for k,v in self.selectview.status().items() if v == 1],
        )
        print(' Done!')
    
    def process(self):

        # Run the M360 base queries directly via Python ODBC
        # M360_BASE, M360_QUALITY
        if ('queries' not in args.skip) and (not args.renderonly):

            print('Running base queries...', flush=True, end='\r')

            DBCONN = get_connection(self.username.get(), self.pw.get(), DB_HOSTNAME, 5433, DB_DATABASE)

            query_db(DBCONN, 'query_M360_BASE', fetch=False, context=self.get_context())
            query_db(DBCONN, 'query_M360_QUALITY', fetch=False, context=self.get_context())

            print('Running base queries... Done!')

            DBCONN.close()

        context = self.get_context()
        if context['dual_ind'] == 'Non-Dual':
            self.analyze_and_render(dual_ind = 0)
        elif context['dual_ind'] == 'Dual':
            self.analyze_and_render(dual_ind = 1)
        else:
            self.analyze_and_render(dual_ind = 0)
            self.analyze_and_render(dual_ind = 1)
        
        if args.save_tables or ('cleanup' in args.skip):
            print("Tables are not being cleaned up.")
        else:
            print("Clean up tables... ", end = '')

            DBCONN = get_connection(self.username.get(), self.pw.get(), DB_HOSTNAME, 5433, DB_DATABASE)
            query_db(DBCONN, 'DROP TABLE IF EXISTS M360_BASE', fetch=False)
            query_db(DBCONN, 'DROP TABLE IF EXISTS M360_QUALITY', fetch=False)

            # Attempt to clear out image folder
            for image in os.listdir('images'):
                try:
                    os.unlink(os.path.join('images', image))
                except:
                    pass

            print('Done!')


    def run_m360(self):
        self.finalWin.attributes("-topmost", 0)
        self.finalWin.withdraw()
        self.start_time = time.time()
        
        # Attempt to log results (do nothing if it fails)
        if not args.nolog:
            try:
                context = self.get_context()
                del context['pwd']
                context['time'] = time.strftime('%Y-%m-%d_%H:%M:%S', time.gmtime())
                context = json.dumps(context)
                
                DBCONN = get_connection(self.username.get(), self.pw.get(), DB_HOSTNAME, 5433, DB_DATABASE)
                
                q = f'''INSERT INTO PMQIDEV.M360_USE_LOG VALUES ('{context}')'''
                query_db(DBCONN, q, fetch=False)
                DBCONN.commit()
                
            except Exception as e:
                if args.debug:
                    print(e)
                pass

        self.process()

        self.end_time = time.time()
        self.finalWin.attributes("-topmost", 1)
        # Add one final window that shows run statistics and lets you terminate the program
        self.finalWin.withdraw()
        self.close_m360()

    def close_m360(self):
        # Build a final window to output summary stats
        self.summaryWin = Toplevel()
        self.summaryWin.title("Final Output")
        self.summaryWin.attributes("-topmost", 1)
        self.summaryWin.protocol("WM_DELETE_WINDOW", self.on_exit)
        self.summaryWin.tk.call('wm', 'iconphoto', self.summaryWin._w, PhotoImage(file="assets/m360_icon.png"))

        Label(self.summaryWin, text = "Thank you for using Member360!").grid(row = 0, column = 0, pady = 5, padx = 5, sticky = 'w')
        Label(self.summaryWin, text = "Input Cohort: " + self.cohort.get(), anchor = 'w').grid(row = 1, column = 0, pady = 5, padx = 5, sticky = 'w')
        Label(self.summaryWin, text = "Cohort Name: " + self.report.get(), anchor = 'w').grid(row = 2, column = 0, pady = 5, padx = 5, sticky = 'w')
        hours, rem = divmod(self.end_time-self.start_time, 3600)
        minutes, seconds = divmod(rem, 60)
        runtime = "{:0>2}:{:0>2}:{:05.2f}".format(int(hours),int(minutes),seconds)
        Label(self.summaryWin, text = "Runtime: " + runtime).grid(row = 3, column = 0, pady = 5, padx = 5, sticky = 'w')

        ttk.Button(self.summaryWin, text = "Back", command = self.go_back_summarywin, style = 'my.TButton').grid(row = 4, column = 0, pady = 5, padx = 5)
        ttk.Button(self.summaryWin, text = "Close", command = self.on_exit, style = 'my.TButton').grid(row = 4, column = 1, pady = 5, padx = 5)


def create_venv(pythonpath, envroot, packages = None, install_only = False, trusted_host_override = False):
    ''' Create virtual environment with a given Python
    in a given environment and, if specified, install
    a set of packages
    '''

    if not install_only:
        cmd = [pythonpath, '-m', 'venv', envroot + '/.env']
        subprocess.call(cmd)

    envpython = os.path.join(envroot, '.env', 'Scripts', 'python')


    if packages is not None:

        _ = []
        if trusted_host_override:
            _ = ['--trusted-host','pypi.org','--trusted-host','files.pythonhosted.org']

        cmd = [envpython, '-m', 'pip', 'install'] + _ + packages
        subprocess.call(cmd)


def restart_in_venv(envroot, scriptpath, argstring = [], fullquote = False):
    ''' Using a given environment, restart the
    script in that environment
    '''

    activate_bat = os.path.join(envroot, '.env', 'Scripts', 'activate.bat')

    if fullquote:
        argstring = [f'"{x}"' for x in argstring]

    startscript = tempfile.NamedTemporaryFile(suffix='.bat', delete=False)

    startcontents = b'\n'.join([
        b'@ECHO OFF',
        f'cd "{envroot}"'.encode(),
        f'call "{activate_bat}"'.encode(),
        f'python "{scriptpath}" {" ".join(argstring)}'.encode(),
        b''
    ])

    startscript.write(startcontents)

    startscript.close()

    subprocess.call(startscript.name)

    os.unlink(startscript.name)



if __name__ == '__main__':

    thispython = sys.executable
    thisfile = os.path.realpath(__file__)
    thispath = os.path.dirname(thisfile)

    parser = argparse.ArgumentParser()
    parser.add_argument('--environment', action = 'store_true')
    parser.add_argument('--skip', action = 'append', default = [])
    parser.add_argument('--keep', action = 'store_true', dest = 'save_tables')
    parser.add_argument('--no-validate', action = 'store_true', dest = 'novalidate')
    parser.add_argument('--ignore-missing-tables', action = 'store_true', dest = 'ignoremissing')
    parser.add_argument('--save-render', action = 'store_true', dest = 'saverender')
    parser.add_argument('--render-only', action = 'store_true', dest = 'renderonly')
    parser.add_argument('--debug', action = 'store_true', dest = 'debug')
    parser.add_argument('--no-log', action = 'store_true', dest = 'nolog')

    args = parser.parse_args(sys.argv[1:])
    if not os.path.exists(os.path.join(thispath, 'images')):
        os.mkdir(os.path.join(thispath, 'images'))

    if not os.path.exists(os.path.join(thispath, 'output')):
        os.mkdir(os.path.join(thispath, 'output'))

    # Logic to instantiate a virtual environment
    # if one does not exist, install the requisite
    # packages, and subsequently rebtoot the script
    # into that environment
    if not os.path.exists(os.path.join(thispath, '.env')):
        print('Creating virtual environment... ', end='', flush=True)
        create_venv(thispython, thispath, ['pyodbc', 'pandas', 'jinja2', 'openpyxl'], False, True)
        print('Done!')

    if args.environment:
        if args.debug:
            print('Running in environment')

        import components
        import pandas as pd
        import pyodbc

        from query import *
        from htmlgenerator import generate_report


        # Create main root window, instantiate the object, and run the main loop
        rootWin = tkinter.Tk()
        rootWin.title("Member360")
        rootWin.option_add("*Font", "helvetica 10")
        ##rootWin.geometry("800x260")
        rootWin.tk.call('wm', 'iconphoto', rootWin._w, PhotoImage(file="assets/m360_icon.png")) # Set the icon
        app = intro_screen(rootWin)
        rootWin.mainloop()

    else:
        if args.debug:
            print('Rebooting script into environment...')
        
        restart_in_venv(
            thispath,
            thisfile,
            ['--environment'] + sys.argv[1:],
            fullquote=True
        )