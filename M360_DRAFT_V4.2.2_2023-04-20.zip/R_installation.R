# R installation script

cat(paste("Beginning R Installation Script at:", Sys.time()))

install.wrapper <- function(package.name) {
	# Wrapper function to install packages via
	# CRAN repository... Helpful if new user has not
	# set default repository.
	install.packages(package.name, repos="http://cran.us.r-project.org")
}

package.list <- c("DBI", "odbc", "tidyverse", "lubridate", "openxlsx", "gt", "sf", "classInt", "scales")
lapply(package.list, install.wrapper)

cat(paste("\nR Package Installation complete at:", Sys.time()))
