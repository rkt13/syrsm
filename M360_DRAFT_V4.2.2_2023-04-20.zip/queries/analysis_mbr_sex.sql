--jinja variables
--dual_ind
--cohort_name
--comparison_name

SELECT
	MBR_SEX_DESC,
	SUM(COHORT_IND) AS {{cohort_name}},
	SUM(COMPARISON_IND) AS {{comparison_name}}
FROM M360_BASE
WHERE DUAL_IND = {{dual_ind}}
GROUP BY 1;