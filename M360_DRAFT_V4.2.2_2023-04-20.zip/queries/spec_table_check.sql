SELECT
  UPPER(object_schema)||'.'||UPPER(object_name) AS table_name
FROM v_catalog.grants
WHERE
  UPPER(privileges_description) LIKE '%SELECT%' AND
  UPPER(object_type) = 'TABLE'
;