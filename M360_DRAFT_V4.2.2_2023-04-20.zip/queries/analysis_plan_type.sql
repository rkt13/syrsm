--jinja variables
--dual_ind
--cohort_name
--comparison_name

SELECT 
	PLAN_GROUP AS PLAN_TYPE, 
	SUM(COHORT_IND) AS {{cohort_name}}, 
	SUM(COMPARISON_IND) AS {{comparison_name}}
FROM M360_BASE 
WHERE dual_ind = {{dual_ind}} 
GROUP BY 1;
