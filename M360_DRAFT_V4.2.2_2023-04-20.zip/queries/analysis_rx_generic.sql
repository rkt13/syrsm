--Jinja Variables
--dual_ind
--start_date
--end_date
--cohort_name
--comparison_name
-- DRUGLIST1


SELECT
  '{{cohort_name}}' AS GROUP,
  BRAND_GENERIC,
  COUNT(*) AS N_CLAIMS,
  SUM(PAID_AMOUNT) AS PAID_AMOUNT
FROM {{TBL_DRUGLIST1}} RX
JOIN M360_BASE BASE
  ON RX.MBR_ID = BASE.MBR_ID
WHERE 
  BASE.COHORT_IND = 1 AND 
  BASE.DUAL_IND = {{dual_ind}} AND 
  RX.SRV_DT BETWEEN '{{start_date}}' AND '{{end_date}}'
GROUP BY 1,2

UNION

SELECT
  '{{comparison_name}}' AS GROUP,
  BRAND_GENERIC,
  COUNT(*) AS N_CLAIMS,
  SUM(PAID_AMOUNT) AS PAID_AMOUNT
FROM {{TBL_DRUGLIST1}} RX
JOIN M360_BASE BASE
  ON RX.MBR_ID = BASE.MBR_ID
WHERE 
  BASE.COMPARISON_IND = 1 AND 
  BASE.DUAL_IND = {{dual_ind}} AND 
  RX.SRV_DT BETWEEN '{{start_date}}' AND '{{end_date}}'
GROUP BY 1,2							 
;							 