--jinja variables
--dual_ind
--cohort_name
--comparison_name

SELECT
 RACE_DESCRIPTION,
 '{{cohort_name}}' as Group,
 SUM(COHORT_IND) AS N
FROM M360_BASE
WHERE DUAL_IND = {{dual_ind}}
GROUP BY 1,2

UNION ALL

SELECT
 RACE_DESCRIPTION,
 '{{comparison_name}}' as Group,
 SUM(COMPARISON_IND) AS N
FROM M360_BASE
WHERE DUAL_IND = {{dual_ind}}
GROUP BY 1,2

;