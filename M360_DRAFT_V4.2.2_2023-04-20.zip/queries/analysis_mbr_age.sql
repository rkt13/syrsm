--jinja variables
--dual_ind
--cohort_name
--comparison_name

SELECT 
	MBR_AGE, 
	SUM(COHORT_IND) as {{cohort_name}}, 
	SUM(COMPARISON_IND) as {{comparison_name}} 
FROM M360_BASE 
WHERE DUAL_IND = {{dual_ind}}
GROUP BY 1;
