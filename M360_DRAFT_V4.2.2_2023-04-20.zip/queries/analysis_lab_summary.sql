--Jinja Variables
--dual_ind
--start_date
--end_date
--cohort_name
--comparison_name
-- TBL_DD_LAB_CLM_FINAL
  
SELECT
	'Cohort' AS GROUP,
	SUM(PAID_AMT) AS PAID_AMT,
	COUNT(*) AS CLAIM_COUNT
FROM {{TBL_DD_LAB_CLM_FINAL}} LAB
JOIN M360_BASE BASE
	ON LAB.MBR_ID = BASE.MBR_ID
WHERE 
	BASE.COHORT_IND = 1 AND 
	BASE.DUAL_IND = {{dual_ind}} AND
	LAB.SRV_DT BETWEEN '{{start_date}}' and '{{end_date}}'
	
UNION

SELECT
	'Comparison' AS GROUP,
	SUM(PAID_AMT) AS PAID_AMT,
	COUNT(*) AS CLAIM_COUNT
FROM {{TBL_DD_LAB_CLM_FINAL}} LAB
JOIN M360_BASE BASE
	ON LAB.MBR_ID = BASE.MBR_ID
WHERE 
	BASE.COMPARISON_IND = 1 AND 
	BASE.DUAL_IND = {{dual_ind}} AND
	LAB.SRV_DT BETWEEN '{{start_date}}' and '{{end_date}}'
	