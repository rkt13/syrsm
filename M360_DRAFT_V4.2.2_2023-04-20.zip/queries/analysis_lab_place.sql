--Jinja Variables
--dual_ind
--start_date
--end_date
--cohort_name
--comparison_name
-- TBL_DD_LAB_CLM_FINAL

SELECT 
	'Cohort' AS GROUP, 
	PL_OF_SRV_BILL_TYPE_CD, 
	PL_OF_SRV_DESC, 
	COUNT(*) AS N_CLAIMS
FROM {{TBL_DD_LAB_CLM_FINAL}} LAB
JOIN M360_BASE BASE
	ON LAB.MBR_ID = BASE.MBR_ID
WHERE
	BASE.COHORT_IND = 1 AND
	BASE.DUAL_IND = {{dual_ind}} AND
	SRV_DT BETWEEN '{{start_date}}' AND '{{end_date}}'
GROUP BY 1,2,3
		
UNION

SELECT 
	'Comparison' AS GROUP, 
	PL_OF_SRV_BILL_TYPE_CD, 
	PL_OF_SRV_DESC, 
	COUNT(*) AS N_CLAIMS
FROM {{TBL_DD_LAB_CLM_FINAL}} LAB
JOIN M360_BASE BASE
	ON LAB.MBR_ID = BASE.MBR_ID
WHERE
	BASE.COMPARISON_IND = 1 AND
	BASE.DUAL_IND = {{dual_ind}} AND
	SRV_DT BETWEEN '{{start_date}}' AND '{{end_date}}'
GROUP BY 1,2,3
