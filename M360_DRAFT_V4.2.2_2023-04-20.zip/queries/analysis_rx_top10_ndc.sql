--Jinja Variables
--dual_ind
--start_date
--end_date
--cohort_name
--comparison_name
-- DRUGLIST1
	   
WITH COHORT AS (
  SELECT
    '{{cohort_name}}' AS GROUP,
    NVL(NDC, 'No NDC Submitted') as NDC,
    DRUG_LBL_NAME,
    SUM(PAID_AMOUNT) AS PAID_AMOUNT,
    COUNT(DISTINCT BASE.MBR_ID) AS N_UTILIZERS
  FROM {{TBL_DRUGLIST1}} RX
  JOIN M360_BASE BASE
    ON RX.MBR_ID = BASE.MBR_ID
  WHERE 
    BASE.COHORT_IND = 1 AND 
    BASE.DUAL_IND = {{dual_ind}} AND
    RX.SRV_DT BETWEEN '{{start_date}}' AND '{{end_date}}'
  GROUP BY 1,2,3
  ORDER BY 4 DESC
  LIMIT 10),

COMPARISON AS (
  SELECT
    '{{comparison_name}}' AS GROUP,
    NVL(NDC, 'No NDC Submitted') AS NDC,
    DRUG_LBL_NAME,
    SUM(PAID_AMOUNT) AS PAID_AMOUNT,
    COUNT(DISTINCT BASE.MBR_ID) AS N_UTILIZERS
  FROM {{TBL_DRUGLIST1}} RX
  JOIN M360_BASE BASE
    ON RX.MBR_ID = BASE.MBR_ID
  WHERE 
    BASE.COMPARISON_IND = 1 AND 
    BASE.DUAL_IND = {{dual_ind}} AND
    RX.SRV_DT BETWEEN '{{start_date}}' AND '{{end_date}}' AND
	NVL(NDC, 'No NDC Submitted') IN (SELECT NDC FROM COHORT)
  GROUP BY 1,2,3
)
  
  
SELECT * FROM COHORT
UNION
SELECT * FROM COMPARISON;