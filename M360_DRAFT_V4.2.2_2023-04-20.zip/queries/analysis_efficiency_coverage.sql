--jinja variables
--dual_ind
--cohort_name
--comparison_name

SELECT 
    '{{cohort_name}}' AS GROUP,
    CASE WHEN PLAN_NAME_STD IS NULL THEN 'FFS' ELSE PLAN_NAME_STD END as plan_name_std,
	COUNT(*) as N_MEMBERS,
    SUM(ACT_TOT_AMT) AS Actual, 
    SUM(EXP_TOT_AMT) AS Expected,	
	SUM(ACT_IP_ADMIT_CNT) as ACT_IP_ADMIT_CNT,
	SUM(ACT_PPR_CNT) as ACT_PPR_CNT
FROM M360_BASE 
WHERE COHORT_IND = 1 AND
	  DUAL_IND = {{dual_ind}}
GROUP BY 1,2
	
UNION

SELECT 
    '{{comparison_name}}' AS GROUP,
    CASE WHEN PLAN_NAME_STD IS NULL THEN 'FFS' ELSE PLAN_NAME_STD END as plan_name_std,
	COUNT(*) as N_MEMBERS,
    SUM(ACT_TOT_AMT) AS Actual, 
    SUM(EXP_TOT_AMT) AS Expected,
	SUM(ACT_IP_ADMIT_CNT) as ACT_IP_ADMIT_CNT,
	SUM(ACT_PPR_CNT) as ACT_PPR_CNT
FROM M360_BASE 
WHERE COMPARISON_IND = 1 AND
	  DUAL_IND = {{dual_ind}}
GROUP BY 1,2
