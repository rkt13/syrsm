--jinja variables
--start_date
--end_date
--dual_ind
--cohort_name
--comparison_name
-- TBL_MA_ENROLLMENT

SELECT
  '{{cohort_name}}' AS Group,
  MAE.PLAN_NAME_STD,
  COUNT(*) AS MEMBER_MONTHS
FROM {{TBL_MA_ENROLLMENT}} MAE
JOIN M360_BASE BASE
  ON MAE.MBR_ID = BASE.MBR_ID
WHERE 
  BASE.COHORT_IND = 1 AND 
  BASE.DUAL_IND = {{dual_ind}} AND
  MAE.CALENDAR_DATE BETWEEN '{{start_date}}' AND '{{end_date}}'  
GROUP BY 1,2

UNION

SELECT
  '{{comparison_name}}' AS Group,
  MAE.PLAN_NAME_STD,
  COUNT(*) AS MEMBER_MONTHS
FROM {{TBL_MA_ENROLLMENT}} MAE
JOIN M360_BASE BASE
  ON MAE.MBR_ID = BASE.MBR_ID
WHERE 
  BASE.COMPARISON_IND = 1 AND 
  BASE.DUAL_IND = {{dual_ind}} AND
  MAE.CALENDAR_DATE BETWEEN '{{start_date}}' AND '{{end_date}}'  
GROUP BY 1,2
;