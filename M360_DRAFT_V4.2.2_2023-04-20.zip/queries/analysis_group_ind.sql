--jinja variables
--dual_ind
--cohort_name
--comparison_name

SELECT
	'{{cohort_name}}' as Group,
	GROUP_IND AS PREMIUM_GROUP,
	COUNT(*) AS N,
	SUM(ACT_TOT_AMT) AS ACT_TOT_AMT
FROM M360_BASE
WHERE 
	COHORT_IND = 1 AND	
	DUAL_IND = {{dual_ind}}
GROUP BY 1,2

UNION

SELECT
	'{{comparison_name}}' as Group,
	GROUP_IND AS PREMIUM_GROUP,
	COUNT(*) AS N,
	SUM(ACT_TOT_AMT) AS ACT_TOT_AMT
FROM M360_BASE
WHERE 
	COMPARISON_IND = 1 AND	
	DUAL_IND = {{dual_ind}}
GROUP BY 1,2;
