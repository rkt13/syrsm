suppressPackageStartupMessages(library(DBI))
suppressPackageStartupMessages(library(odbc))
suppressPackageStartupMessages(library(tidyverse))
suppressPackageStartupMessages(library(openxlsx))
suppressPackageStartupMessages(library(gt))
suppressPackageStartupMessages(library(sf))
suppressPackageStartupMessages(library(classInt))
suppressPackageStartupMessages(library(lubridate))
options(warn=-1)
options(dplyr.summarise.inform=FALSE)
cat("\nConnecting to Data...")

HPDW <- dbConnect(odbc(),
                  Driver = "Vertica",
                  Server = "{{db_hostname}}",
                  Database = "{{db_database}}",
                  UID = "{{uid}}",
                  PWD = paste("{","{{pwd}}","}",sep="")

)

###################################################
### INPUTS 
cohort_name <- "{{cohort_name}}"
comparison_name <- "{{comparison_name}}"

wd <- getwd()
appendix <- createWorkbook()

bar_color <- "#503278"
dot_color <- "#F2B800"
sbar_color_1 <- "#A776CC"
sbar_color_2 <- dot_color
sbar_color_3 <- "#AFD2E9"

###################################################
### FUNCTION DEFINITIONS

# 100% STACKED BAR PLOTTING
plot_m360 <- function(a_summary, fill_col){
  a_ggplot <- ggplot(data=a_summary, aes(x = Group, y = pct, fill = .data[[fill_col]], label = scales::percent(pct, accuracy = 1))) +
    geom_bar(stat='identity',width = 0.2)+ 
    scale_y_continuous(limits=c(0,1.1)) + 
    geom_text(data=subset(a_summary, round(pct,2) > 0.00), size = 3.7,position = position_stack(vjust=0.5)) + 
    theme_classic() + 
    scale_fill_manual(values=c(sbar_color_1, sbar_color_2, sbar_color_3)) +
    theme(axis.title.y = element_blank(), 
          axis.text.y = element_blank(), 
          axis.ticks.y = element_blank(), 
          axis.line.y = element_blank(), 
          axis.line.x = element_blank(), 
          axis.ticks.x = element_blank(),
          axis.title.x = element_blank(),
          text = element_text(size=14),
          legend.position = "bottom") +
    labs(fill = "" )
  return(a_ggplot)
}

# BAR CHART PLOTTING
plot_m360_bars <- function(a_summary, data_col, flip_axis){
  # This function requires the existence of a 'pct' column with the percent breakdown by group
  # The data_col argument is the field to breakdown the data by
  
  # Get the list of plan types in the cohort
  a_summary_uniques <- a_summary %>% ungroup() %>% filter(Group == cohort_name) %>% select(.data[[data_col]]) %>% unique() %>% unlist %>% unname
  # Filter our data to only the values found in the cohort
  a_summary <- a_summary %>% filter(.data[[data_col]] %in% a_summary_uniques)
  if(flip_axis == "Y"){
    a_ggplot <- ggplot(data=a_summary %>% filter(Group == cohort_name) %>% arrange(desc(pct)), 
                       aes(x=reorder(.data[[data_col]], pct),y=pct))
    a_ggplot <- a_ggplot + geom_bar(stat='identity', width = 0.2, aes(fill = bar_color))
      
  }
  else{
    a_ggplot <- ggplot(data=a_summary %>% filter(Group == cohort_name), mapping=aes(x=reorder(.data[[data_col]], -pct),y=pct))
    a_ggplot <- a_ggplot + geom_bar(stat='identity', width = 0.2, aes(fill = bar_color))
  }
  a_ggplot <- a_ggplot + 
    geom_point(data=a_summary %>% filter(Group == comparison_name), 
               mapping=aes(x=.data[[data_col]],y=pct, color = dot_color), stat='identity', size = 4) +
    theme_classic() + 
    scale_fill_discrete(name = "", labels = cohort_name, type = bar_color) +
    scale_color_discrete(name = "", labels = comparison_name, type=dot_color) +
    labs(fill = "" )
  if(flip_axis == "Y"){
    a_ggplot <- a_ggplot  +
      geom_text(aes(label = scales::percent(pct, accuracy = 1)), position=position_dodge(width=0.9),  hjust=-0.8, size=3.5) +
      scale_y_continuous(labels=scales::percent_format(accuracy = 1),
                         limits=c(0,max(a_summary$pct + 0.05))) + 
      coord_flip()  +
      theme(axis.title.y = element_blank(), 
            axis.ticks.y = element_blank(),
            axis.title.x = element_blank(), 
            text = element_text(size=14), 
            legend.position = "bottom")
  }
  else{
    a_ggplot <- a_ggplot + 
      geom_text(aes(label = scales::percent(pct, accuracy = 1)), position=position_dodge(width=0.9), vjust=-0.5) +
      scale_y_continuous(labels=scales::percent_format(accuracy = 1),
                         limits=c(0,max(a_summary$pct + 0.03))) + 
      theme(axis.title.y = element_blank(), 
            axis.title.x = element_blank(), 
            text = element_text(size=14), 
            legend.position = "bottom")
  }
  return(a_ggplot)
}

#MANIPULATE DEMOGRAPHIC DATAFRAMES
pivot_longer_m360 <- function(df, col) {
  new <- df %>% 
    pivot_longer(-all_of(col), names_to = "Group", values_to = "N") %>% 
    group_by(Group) %>% 
    mutate(pct = N/sum(N))
  
  return(new)
}

# RESHAPE TABLES FROM LONG TO WIDE
appendix_pivot_m360 <- function(df, col_name) {
  tbl <- pivot_wider(df, names_from = Group, values_from = c(N, pct))
  return(tbl)
}

# WRITE TABLE TO APPENDIX
write_appendix_M360 <- function(wb, sheetName, tbl) {
  tbl <- tbl %>% mutate_if(is.double, as.numeric)
  addWorksheet(wb, sheetName)
  writeData(wb, sheetName, tbl, keepNA = TRUE)
}

#CHECKS DATATYPE FOR INTEGER64
is.integer64 <- function(x){
  class(x)=="integer64"
}

{% if debug==False %}
tryCatch({
{% endif %}

###########################################################
### SECTION 1: EXECUTIVE SUMMARY 

### TABLE 1.1 - Data Quality Summary

data_quality_df <- dbGetQuery(HPDW, "{{QRY_ANALYSIS_INCLUSION}}")
data_quality_summary <- data_quality_df %>% 
                    arrange(rev(MEASURE)) %>% 
                    mutate_if(is.integer64, as.numeric) %>% 
                    mutate(pct = TOTAL/max(TOTAL))

data_quality_summary$MEASURE = c("Submitted Members", "Submitted Members w/ Eligiblity, Spend, and Utilization Data")


data_quality_summary %>% gt() %>% 
  cols_label(MEASURE = "", NONDUAL = "Non-Dual", DUAL = "Dual", TOTAL = "Total", pct = "% Remaining") %>% 
  sub_missing(columns = vars(NONDUAL, DUAL), missing_text = "") %>%
  fmt_number(columns = vars(NONDUAL, DUAL, TOTAL),decimals=0) %>% 
  fmt_percent(columns = vars(pct), decimals=0) %>% 
  tab_style(
    # Set the vertical lines around the first column
    style = list(cell_borders(sides = c("left", "right"), color = "#d6dadc", style = "solid", weight = px(2))),
    locations = list(cells_body(columns = vars(MEASURE), rows = everything()),
                     cells_column_labels(columns = vars(MEASURE)))) %>% 
  tab_style(
    # Set the vertical line around the right side of the last column
    style = list(cell_borders(sides = "right", color = "#d6dadc", style = "solid", weight = px(2))),
    locations = list(cells_body(columns = vars(pct), rows = everything()),
                     cells_column_labels(columns = vars(pct)))) %>%
  tab_style(
    # Set the appropriate column to bold
    style = list(cell_text(weight="bold")),
    {% if dual_ind == 0 %}
    locations = list(cells_body(columns = vars("NONDUAL"), rows=everything()))
    {% else %}
    locations = list(cells_body(columns = vars("DUAL"), rows=everything()))
    {% endif %}
  ) %>%
  
  tab_style(
    # Bold Column Headers
    style = list(cell_text(weight = "bold")),
    locations = list(cells_column_labels(columns = everything()))
  ) %>% 
  
  cols_width(
    vars(MEASURE) ~ px(390),
    vars(NONDUAL) ~ px(85),
    vars(DUAL) ~ px(85),
    vars(TOTAL) ~ px(85), 
    vars(pct) ~ px(125)
  ) %>% 
  cols_align(
    align = c("right"),
    columns = c("TOTAL")
   ) %>%
  gtsave(paste0(wd, "/images/data_quality_table.html"))

write_appendix_M360(appendix, "1.1 - Data Quality", data_quality_summary)

### FIGURE 1.2 - POPULATION SUMMARY
pop_df <- dbGetQuery(HPDW, "{{QRY_ANALYSIS_SUMMARY}}")

pop_summary <- pop_df %>% 
               mutate_if(is.double, as.numeric) %>% 
               mutate(PMPM = ACT_TOT_AMT/MEMBER_MONTHS) %>% 
               select(-PREMIUM_PD, PREMIUM_PD) %>% 
               pivot_longer(-GROUP, names_to = "Measure", values_to = "Value") %>% 
               pivot_wider(id_cols = Measure, names_from = GROUP, values_from = Value) %>% 
               mutate(pct = Cohort/Comparison) %>% 
               select(Measure, Cohort, Comparison, pct)


Cohort_N <- pop_summary$Cohort[1]
Comparison_N <- pop_summary$Comparison[1]

Cohort_MM <- pop_summary$Cohort[2]
Comparison_MM <- pop_summary$Comparison[2]

pop_summary$Measure = c("Number of Members Included In Report",
                        "Total Member Months in Period",
                        "Total Fee-for-Service (FFS) + Plan Reported Amount",
                        "FFS + Plan Reported Per Member Per Month (PMPM)", 
                        "Capitation Claims Paid")

pop_summary_table <- pop_summary %>% gt() %>% 
  cols_label(Measure = "Measure", Cohort = cohort_name, Comparison = comparison_name, pct = str_glue("% of {comparison_name}")) %>% 
  fmt_number(columns = vars(Cohort, Comparison), rows = 1:2, decimals=0) %>% 
  fmt_currency(columns = vars(Cohort, Comparison), rows = 3:5, decimals=0, currency = "USD") %>% 
  fmt_percent(columns = vars(pct), decimals=0) %>%
  tab_style(
    # Set the vertical lines around the first column
    style = list(cell_borders(sides = c("left", "right"), color = "#d6dadc", style = "solid", weight = px(2))),
    locations = list(cells_body(columns = vars(Measure), rows = everything()),
                     cells_column_labels(columns = vars(Measure)))) %>% 
  tab_style(
    # Set the vertical line around the right side of the last column
    style = list(cell_borders(sides = "right", color = "#d6dadc", style = "solid", weight = px(2))),
    locations = list(cells_body(columns = vars(pct), rows = everything()),
                     cells_column_labels(columns = vars(pct)))) %>%
  tab_style(
    # Bold Column Headers
    style = list(cell_text(weight = "bold")),
    locations = list(cells_column_labels(columns = everything()))
  ) %>% 
  cols_width(
    vars(Measure) ~ px(320),
    vars(Cohort) ~ px(150),
    vars(Comparison) ~ px(150),
    vars(pct) ~ px(150)
  ) %>% 
  # Write out to png
  gtsave(paste0(wd,"/images/population_summary_table.html"))

write_appendix_M360(appendix, "1.2 - Population Summary", pop_summary)

### TABLE/FIGURE 1.3 SPENDING SUMMARY
cos <- c("Emergency", "Inpatient", "Outpatient", "Pharmacy", "Professional", "Skilled Nursing Facility")

cos_df <- dbGetQuery(HPDW, "{{QRY_ANALYSIS_COS_SUMMARY}}")

cos_summary <- cos_df %>% 
  mutate_if(is.integer64, as.numeric) %>% 
  pivot_longer(cols = ACT_ER_AMT:ACT_SNF_AMT, names_to = "cos") %>% 
  pivot_wider(names_from = GROUP, values_from = value) %>% 
  mutate(COHORT_PMPM = COHORT/Cohort_MM, 
         COMPARISON_PMPM = COMPARISON/Comparison_MM, 
         COHORT_PCT = COHORT/sum(COHORT), 
         COMPARISON_PCT = COMPARISON/sum(COMPARISON))

cos_summary$cos <- cos
cos_summary <- cos_summary %>% bind_rows(summarise_all(.,funs(if(is.numeric(.)) sum(.) else "Total")))

cos_table <- cos_summary %>%
  select(cos, COHORT, COHORT_PMPM, COHORT_PCT, COMPARISON_PMPM, COMPARISON_PCT) %>% 
  gt() %>% 
  cols_label(cos = "Category of Service (COS)", 
             COHORT = cohort_name, 
             COHORT_PMPM = str_glue("{cohort_name} PMPM"), 
             COHORT_PCT = str_glue("{cohort_name} % of Total"), 
             COMPARISON_PMPM = str_glue("{comparison_name} PMPM"), 
             COMPARISON_PCT = str_glue("{comparison_name} % of Total")) %>% 
  fmt_currency(columns = vars(COHORT, COHORT_PMPM, COMPARISON_PMPM), decimals=0, currency = "USD") %>%
  fmt_percent(columns = vars(COHORT_PCT, COMPARISON_PCT), decimals=0) %>% 
  tab_style(
    # Set the vertical lines around the first column
    style = list(
      cell_borders(sides = c("left", "right"), color = "#d6dadc", style = "solid", weight = px(2))
    ),
    locations = list(cells_body(columns = vars(cos), rows = everything()),
                     cells_column_labels(columns = vars(cos)))
  )%>% 
  tab_style(
    # Set the vertical line around the right side of the last column
    style = list(cell_borders(sides = "right", color = "#d6dadc", style = "solid", weight = px(2))),
    locations = list(cells_body(columns = vars(COMPARISON_PCT), rows = everything()),
                     cells_column_labels(columns = vars(COMPARISON_PCT)))) %>%
  tab_style(
    # Bold Column Headers
    style = list(cell_text(weight = "bold")),
    locations = list(cells_column_labels(columns = everything()))
  ) %>% 
  tab_style(
    # Bold Total Row
    style = list(cell_text(weight = "bold")),
    location = list(cells_body(columns = everything(), rows = 7))
  ) %>% 
  cols_width(
    vars(cos) ~ px(230),
    vars(COHORT) ~ px(150),
    vars(COHORT_PMPM) ~ px(85),
    vars(COHORT_PCT) ~ px(100),
    vars(COMPARISON_PCT) ~ px(105),
    vars(COMPARISON_PMPM) ~ px(100)
  ) %>% 
  # Write out to png
  gtsave(paste0(wd,"/images/cos_spend_table.html"))


cos_plot_data <- gather(data = (cos_summary %>% filter(cos != "Total") %>% 
                                  select(cos, COHORT_PCT, COMPARISON_PCT) %>% 
                                  rename(!!cohort_name:=COHORT_PCT, !!comparison_name:=COMPARISON_PCT)), key = "Group", value = "pct", c(2,3))

cos_spend_plot <- ggplot(data = cos_plot_data, mapping = aes(x = Group, y = pct, fill = fct_rev(cos), label = scales::percent(pct, accuracy = 1))) + 
                  geom_bar(stat='identity',width = 0.2)+ 
                  theme_classic() + 
                  geom_text(data=subset(cos_plot_data, round(pct,2) > 0.00), size = 3.7,position = position_stack(vjust=0.5)) + 
                  scale_fill_manual(values= c("#AFD2E9", "#779FA1", "#88498F", "#7030A0", "#F2B800", "#503278"), guide = guide_legend(reverse = TRUE)) +
                  scale_x_discrete(limits = unique(rev(cos_plot_data$Group))) + 
                  scale_y_continuous(labels = scales::percent_format(accuracy=1)) +
                  coord_flip() + 
                  theme(axis.title.y = element_blank(), 
                        #axis.text.y = element_blank(), 
                        #axis.ticks.y = element_blank(), 
                        #axis.line.y = element_blank(), 
                        #axis.line.x = element_blank(), 
                        axis.ticks.x = element_blank(),
                        axis.title.x = element_blank(),
                        text = element_text(size=11),
                        legend.position = "bottom", 
                        legend.text = element_text(size = 8)) +
                  labs(fill = "" )
#cos_spend_plot
ggsave(plot = cos_spend_plot, filename = paste0(wd, "/images/cos_pmpm.png"), width=8, height = 3.5, units = 'in', dpi=300)

#Write data to appendix
write_appendix_M360(appendix, "1.3 - Spend by COS",cos_summary)

### FIGURE 1.4 - ENROLLMENT TREND OVER TIME
mbr_trend <- dbGetQuery(HPDW, "{{QRY_ANALYSIS_ENROLLMENT_TREND}}")

enr_year_end <- mbr_trend %>% 
                filter(CALENDAR_DATE == floor_date(as.Date("{{end_date}}"), "months")) %>%
                select(N_MBR) %>% 
                pull()

mbr_trend$N_MBR <- as.numeric(mbr_trend$N_MBR)
mbr_trend <- mbr_trend %>% 
             mutate(pct = N_MBR/enr_year_end,
					CALENDAR_DATE = as.Date(CALENDAR_DATE)) %>% 
             arrange(CALENDAR_DATE)

enr_trend_plot <- ggplot(data = mbr_trend, mapping = aes(x = CALENDAR_DATE, y = pct)) + 
  geom_rect(xmin = as.Date("{{start_date}}"), xmax = as.Date("{{end_date}}"), ymin = -Inf, ymax = Inf, fill = "#D3D3D305") +
  geom_line(fill = bar_color) +
  geom_point(color = bar_color, size = 2) +
  geom_hline(yintercept = 1, color="#444444", linetype="dashed") +
  labs(x = "Month", y = "Enrolled Members (as % of Year End)") +
  scale_x_date(date_breaks = "years", date_labels = "%Y") + 
  scale_y_continuous(limits = c(0, 1.2),
                     labels = scales::percent_format(accuracy=1.0)) +
  theme_classic() +
  theme(text = element_text(size=12),
        panel.grid.major = element_line(size = 0.1, color = "black", linetype = 2),
        panel.background = element_rect(fill = NA),
        panel.ontop = TRUE)


ggsave(plot = enr_trend_plot, filename = paste0(wd, "/images/mbr_trend.png"), width=8, height = 3.5, units = 'in', dpi=300)

write_appendix_M360(appendix, "1.4 - Enrollment Trend", mbr_trend)

cat("\nSection 1 Complete")

{% if debug==False %}

},
error = function(e){message("ERROR:", e)}
#warning = function(w){message("WARNING:", w)}
)
{% endif %}


{% if debug==False %}
tryCatch({
{% endif %}

##############################################
###SECTION 2: DEMOGRAPHICS

# FIGURE 2.1 - SEX

#Assemble data

sex_df <- dbGetQuery(HPDW, "{{QRY_ANALYSIS_MBR_SEX}}")

sex_summary <- pivot_longer_m360(sex_df, "MBR_SEX_DESC")

#Create plot
sex_plot <- plot_m360(sex_summary, "MBR_SEX_DESC") %>% invisible()
ggsave(plot = sex_plot, filename = paste0(wd, "/images/mbr_sex.png"), width = 4, height = 3.5, units = "in", dpi=300)

#Write data to appendix
sex_appendix <- appendix_pivot_m360(sex_summary, "MBR_SEX_DESC")
write_appendix_M360(appendix, "2.1 - Member Sex", sex_appendix)

#FIGURE 2.2 - MC/FFS

#Assemble data

mc_ffs_df <- dbGetQuery(HPDW, "{{QRY_ANALYSIS_MC_FFS}}")
mc_ffs_summary <- pivot_longer_m360(mc_ffs_df, "MC_FFS") 

#Create plot
mc_ffs_plot <- plot_m360(mc_ffs_summary, "MC_FFS") %>% invisible()
ggsave(plot = mc_ffs_plot, filename = paste0(wd, "/images/mcffs.png"), width = 4, height = 3.5, units = "in", dpi=300)

#Write data to appendix
mc_ffs_appendix <- appendix_pivot_m360(mc_ffs_summary, "MC_FFS")
write_appendix_M360(appendix, "2.2 - MC-FFS", mc_ffs_appendix)


#FIGURE 2.3 - AGE

#Assemble data

age_df <- dbGetQuery(HPDW, "{{QRY_ANALYSIS_MBR_AGE}}")

age_summary <- pivot_longer_m360(age_df, "MBR_AGE")

#Create plot
age_plot <- ggplot() + geom_bar(data = age_summary,aes(x=MBR_AGE, y=pct), stat='identity', fill=bar_color, colour=bar_color) +
  geom_vline(xintercept = 65, color="#444444", linetype="dashed") + 
  facet_wrap( ~ Group, ncol=2, scales = "fixed") + 
  scale_x_continuous(limits=c(-0.5,100)) +
  scale_y_continuous( labels=function(pct) paste0(pct*100, "%")) +
  theme_classic() +
  xlab("Age") + ylab("% of Total") + 
  theme(text = element_text(size=12),
        strip.text = element_text(size=12),
        legend.position = "bottom", 
        legend.text = element_text(size = 10)) +
        labs(fill = "" ) %>% invisible()
  

#Write plot to file
ggsave(plot = age_plot, filename = paste0(wd, "/images/mbr_age.png"), width = 8.25, height = 3.5, units = 'in', dpi=300)

#Write data to appendix
age_appendix <- age_df %>% arrange(MBR_AGE)
write_appendix_M360(appendix,"2.3 - Member Age", age_appendix)


#FIGURE 2.4 - MEMBER RACE

race_df <- dbGetQuery(HPDW, "{{QRY_ANALYSIS_MBR_RACE}}")

race_summary <- race_df %>% 
                group_by(Group) %>% 
                mutate(pct = N/sum(N)) %>% 
                select(Group, RACE_DESCRIPTION, N, pct) %>% 
                arrange(Group, RACE_DESCRIPTION) %>% 
                ungroup()

race_plot <- plot_m360_bars(race_summary, "RACE_DESCRIPTION", "Y")

ggsave(plot = race_plot, filename = paste0(wd, "/images/mbr_race.png"), width = 8.25, height = 3.5, units = "in", dpi=300)

write_appendix_M360(appendix, "2.4 - Member Race", race_summary)

#FIGURE 2.5 -HEALTH HOME INDICATOR
#Assemble data

hh_df <- dbGetQuery(HPDW, "{{QRY_ANALYSIS_HEALTH_HOME}}")

hh_summary <- pivot_longer_m360(hh_df, "HH_IND")

#Create plot
hh_plot <- plot_m360(hh_summary, "HH_IND") %>% invisible()
ggsave(plot = hh_plot, filename = paste0(wd, "/images/hh_ind.png"), width = 4, height = 3.5, units = "in", dpi=300)

#Write data to appendix
hh_appendix <- appendix_pivot_m360(hh_summary, "HH_IND")
write_appendix_M360(appendix, "2.5 - Health Home Enrollment", hh_appendix)

#FIGURE 2.6 - MEMBER CRG

crg_df <- dbGetQuery(HPDW, "{{QRY_ANALYSIS_MBR_CRG}}")

no_data_for_crg_msg <- paste("CRG data is not available for the selected year.\n",
                             "This figure is not shown in the report.")

if(nrow(crg_df) == 0){
  crg_plot <- ggplot() +
    annotate("text", x = 0, y = 0, label = no_data_for_crg_msg) + 
    theme_void()
  
  crg_appendix <- crg_df
} else {
  crg_summary <- crg_df %>% 
    group_by(GROUP) %>% 
    mutate(pct = N_MBR/sum(N_MBR),
           CRG_print = str_wrap(str_c(CRG1, " - ", CRG_DESC), 32)) %>% 
    ungroup()
  
  crg_plot <- ggplot(crg_summary, aes(x=CRG1, y=pct, fill=GROUP, color = CRG_print)) + 
    geom_bar(stat= 'identity') +
    geom_text(aes(label = scales::percent(pct, accuracy = 1)), vjust=-0.4, show.legend=FALSE, size = 3.5) +
    scale_fill_manual(values = c( "#503278","#F2B800"), guide = "none") +
    scale_color_manual(name = "CRG Descriptions", values = rep.int("#0B2632", 10), guide = guide_legend(override.aes=aes(fill=NA)))+
    scale_y_continuous(labels = scales::percent_format())+
    theme_classic()+
    theme(strip.text = element_text(size=12),
          legend.key = element_rect(colour = "white", size = 0),
          legend.key.width = unit(0, "cm"),
          legend.key.height = unit(0.8, "cm"),
          legend.title = element_text(size = 11), 
          legend.text = element_text(size = 9)) +
    facet_wrap(~GROUP) +
    labs(x = "CRG", 
         y = "% of Members")
  
  crg_appendix <- crg_summary %>% select(GROUP, CRG_print, N_MBR, pct) %>% arrange(GROUP, CRG_print)
}

ggsave(plot = crg_plot, filename = paste0(wd, "/images/mbr_crg.png"), width = 8.25, height = 5, units = "in", dpi = 300)

write_appendix_M360(appendix, "2.6 - 3M CRG", crg_appendix)


# FIGURE 2.7 - % Spend by Premium Group

spend_pg_df <- dbGetQuery(HPDW, "{{QRY_ANALYSIS_GROUP_IND}}")

spend_pg_summary <- spend_pg_df %>% group_by(Group) %>% mutate(pct = N/sum(N, na.rm = TRUE))

#Create plot
spend_pg_plot <- plot_m360_bars(spend_pg_summary,"PREMIUM_GROUP", "Y") 
ggsave(plot = spend_pg_plot, filename = paste0(wd, "/images/spend_pg.png"), width=8.25, height=3.5, units='in', dpi=300)

#Write data to appendix
spend_pg_appendix <- spend_pg_summary %>% pivot_wider(id_cols = PREMIUM_GROUP, names_from = Group, values_from = c(N, pct))
write_appendix_M360(appendix, "2.7 - Premium Group" ,spend_pg_appendix)

#FIGURE 2.8 - PLAN TYPE
#Assemble data

plan_type_df <- dbGetQuery(HPDW, "{{QRY_ANALYSIS_PLAN_TYPE}}")
plan_type_summary <- pivot_longer_m360(plan_type_df, "PLAN_TYPE")

#Create plot
plan_type_plot <- plot_m360_bars(plan_type_summary, "PLAN_TYPE", "Y") %>% invisible()
ggsave(plot = plan_type_plot, filename = paste0(wd, "/images/plan_type.png"), width = 8.25, height = 3.5, units = "in", dpi=300)

#Write data to appendix
plan_type_appendix <- appendix_pivot_m360(plan_type_summary, 'PLAN_TYPE')
write_appendix_M360(appendix,"2.8 - Plan Type", plan_type_appendix)

# FIGURE 2.9 - MEMBER MONTHS BY COVERAGE

coverage_df <- dbGetQuery(HPDW, "{{QRY_ANALYSIS_COVERAGE}}")
plan_coverage_summary <- coverage_df %>% group_by(Group) %>% mutate(pct = MEMBER_MONTHS/sum(MEMBER_MONTHS, na.rm = TRUE))

top10_coverage <- plan_coverage_summary %>% filter(Group == cohort_name) %>% arrange(desc(pct)) %>% head(10) %>% select(Group, PLAN_NAME_STD)
top10_coverage_summary <- plan_coverage_summary %>% filter(PLAN_NAME_STD %in% top10_coverage$PLAN_NAME_STD)

#Create plot
plan_coverage_plot <- plot_m360_bars(top10_coverage_summary, "PLAN_NAME_STD", "Y") %>% invisible()

#Write plot to file
ggsave(plot = plan_coverage_plot, filename = paste0(wd, "/images/coverage_mm.png"), width = 8.25, height = 3.5, units = 'in', dpi=300)

#Write data to appendix
plan_coverage_appendix <- plan_coverage_summary %>% 
                          pivot_wider(id_cols = PLAN_NAME_STD, names_from = 'Group', values_from = c(MEMBER_MONTHS, pct)) %>% 
                          arrange(PLAN_NAME_STD)
write_appendix_M360(appendix, "2.9 - Top Coverage", plan_coverage_appendix)

cat("\nSection 2 Complete")

{% if debug==False %}

},
error = function(e){message("ERROR:", e)}
#warning = function(w){message("WARNING:", w)}
)
{% endif %}

{% if debug==False %}
tryCatch({
{% endif %}

#####################################################################
## SECTION 3: CHURN

churn_df <- dbGetQuery(HPDW, "{{QRY_ANALYSIS_CHURN}}")

#Plan Group Churn summary
group_order <- c("FFS", "MMC", "MLTC", "HARP", "HIV SNP", "OTHERS", "Not in Medicaid")

churn_group_summary <- churn_df %>% 
  mutate(END = if_else(END_GROUP=="Medicaid Managed Care", "MMC", END_GROUP),
         START = if_else(START_GROUP=="Medicaid Managed Care", "MMC", START_GROUP)) %>% 
  complete(GROUP, START, END, fill = list(N=0)) %>% 
  mutate(N=if_else(is.na(N),0,as.numeric(N))) %>%
  group_by(GROUP, START, END) %>% 
  summarise(n = sum(N)) %>%
  mutate(n = as.integer(n), n_diag = if_else(START!=END, as.integer(n), as.integer(0))) %>% 
  ungroup() %>% 
  group_by(GROUP, START) %>% 
  mutate(pct = n/sum(n), pct_diag = n_diag/sum(n_diag)) %>% 
  ungroup() %>% 
  mutate(START = factor(START, levels = group_order),
         END = factor(END, levels = group_order))

churn_group_summary$pc[is.na(churn_group_summary$pct)] <- 0
churn_group_summary$pct_diag[is.na(churn_group_summary$pct_diag)] <- 0


#Plan Churn summary (Top 10)
churn_plan_summary <- churn_df %>% 
  mutate(START_PLAN = str_trunc(START_PLAN, 20, "right"),
         END_PLAN = str_trunc(END_PLAN, 20, "right")) %>% 
  complete(GROUP, START_PLAN, END_PLAN, fill = list(N=0)) %>% 
  mutate(N=if_else(is.na(N),0,as.numeric(N))) %>%
  group_by(GROUP, START_PLAN, END_PLAN) %>% 
  summarise(n = sum(N))

top_plans <- churn_plan_summary %>% 
  filter(END_PLAN != "Not in Medicaid",
         GROUP == cohort_name) %>% 
  group_by(END_PLAN) %>% 
  summarise(n = sum(n)) %>% 
  filter(n > 0) %>% 
  slice_max(order_by = n, n=10, with_ties = FALSE) %>%
  select(END_PLAN) %>% 
  unlist() %>% 
  append(., "Not in Medicaid")

order <- unique(top_plans)
order <- order[! order %in% c('Not in Medicaid', 'Other Plans')]
order <- append(order, c('Other Plans', 'Not in Medicaid'))

churn_plan_summary <- churn_plan_summary %>% 
  mutate(END = if_else(END_PLAN %in% unlist(top_plans), END_PLAN, "Other Plans"),
         START = if_else(START_PLAN %in% unlist(top_plans), START_PLAN, "Other Plans")) %>% 
  group_by(GROUP, START, END) %>% 
  summarise(n = sum(n)) %>% 
  mutate(n = as.integer(n), n_diag = if_else(START!=END, as.integer(n), as.integer(0))) %>% 
  ungroup() %>% 
  group_by(GROUP, START) %>% 
  mutate(pct = n/sum(n), pct_diag = n_diag/sum(n_diag)) %>% 
  ungroup() %>% 
  mutate(START = factor(START, levels = order),
         END = factor(END, levels = order))

churn_plan_summary$pc[is.na(churn_plan_summary$pct)] <- 0
churn_plan_summary$pct_diag[is.na(churn_plan_summary$pct_diag)] <- 0

churn_plot <- function(df, group, pct = "Y", fname, axis_title = "Coverage") {
  
  summary <- df %>% filter(GROUP == group)
  
  p <- ggplot(summary, aes(x = END, y = fct_rev(START), fill = pct_diag)) +
    geom_tile( colour = 'gray', show.legend = FALSE) + 
    geom_tile(data = summary %>% filter(START ==END), color = "#3A3B3C", size = 1.2) +
    scale_fill_gradient(low = "white",
                        high = scales::muted("midnightblue")) + 
    scale_x_discrete(position="top", name = paste0(axis_title, " at End of Year")) +
    scale_y_discrete(name = paste0(axis_title, " at Start of Year")) + 
    theme_test() + 
    theme(axis.title = element_text(size = 12),
          axis.text.x = element_text(angle = 90, vjust = 0, hjust=0),
          text=element_text(size=12),
          legend.position = 'none')
  
  if (pct == "Y") { 
    p <- p + geom_text(aes(label = scales::percent(pct, accuracy=1)))
  }
  else {
    p <- p + geom_text(aes(label = scales::comma(n, accuracy=1)), size = 3.15)
  }
  
  ggsave(plot = p, filename = paste0(wd, "/images/", fname, ".png"), dpi = 300, width = 8, height = 4, units ="in")
}

churn_plot(churn_group_summary, cohort_name, "Y", fname = "churn_group_cohort_pct", axis_title = "Coverage Type")
churn_plot(churn_group_summary, comparison_name, "Y", fname = "churn_group_comp_pct", axis_title = "Coverage Type")
churn_plot(churn_plan_summary, cohort_name, "Y", fname = "churn_plan_cohort_pct")
churn_plot(churn_plan_summary, comparison_name, "Y", fname = "churn_plan_comp_pct")

write_appendix_M360(appendix, "3.1-3.2 - Churn by Plan Type", churn_group_summary)
write_appendix_M360(appendix, "3.3-3.4 - Churn by Top Coverage", churn_plan_summary)

cat("\nSection 3 Complete")

{% if debug==False %}

},
error = function(e){message("ERROR:", e)}
#warning = function(w){message("WARNING:", w)}
)
{% endif %}

{% if debug==False %}
tryCatch({
{% endif %}

#################################################################
### SECTION 4: GEOGRAPHIC VIEWS

# Downstate counties list (by FIPS Codes)
# Rockland, Westchester, Bronx, New York, Queens, Kings, Richmond, Nassau, Suffolk
downstate_counties <- c("36087", "36119", "36005", "36061", "36081", "36047", "36085", "36059", "36103")

### FIGURE 4.1 - NYS MAP

# Read in the shapefile. Note that there are two files at varying resolutions, denoted by their storage size.
county_xwalk <- read_csv("assets/fiscal_to_shp_county_xwalk.csv", col_types = cols())
small_nys_counties <- st_read("assets/Counties_Shoreline.shp", quiet = TRUE)

# Retrieve county data and calculate
# proportion of members in cohort vs. comparison
county_data <- dbGetQuery(HPDW, "{{QRY_ANALYSIS_COUNTY_MAP}}")

county_summary <- county_data %>%
  mutate(pct = COHORT / STATEWIDE) %>%
  left_join(county_xwalk, by = "MBR_FISCAL_COUNTY")

# Rename the counties to match the NYS GIS Program Office Counties and remove non-map counties
other_county <- county_summary %>%
  filter(NYS_GIS_COUNTY == 'Other')

county_summary <- county_summary %>% 
  select(-MBR_FISCAL_COUNTY) %>% 
  filter(NYS_GIS_COUNTY != 'Other')

quant_classes <- classIntervals(filter(county_summary, COHORT > 0 & STATEWIDE > 0)$pct, n = 5, style = "quantile")
quant_colors <- c("#d3c5e7", "#A88CCF", "#8961BD", "#603C90", "#301E48")

# Convert the quant_classes to labels that make logical sense
# Lead the classes to get side by side lower and upper bounds
# Drop the NA row, then make our new column to get the final legend value
quant_ranges <- data_frame(lb = pmax(quant_classes$brks,0) %>% scales::percent(0.01), 
                           ub = pmin(lead(quant_classes$brks),1) %>% scales::percent(0.01)) %>% 
  na.omit() %>% 
  mutate(label = paste(lb, ub, sep = "-"))

county_summary <- county_summary %>%
  mutate(quant_classes = cut(pct, quant_classes$brks, include.lowest = TRUE, ordered_result = TRUE)) %>% 
  filter(STATEWIDE > 0)

# Manually make our legend labels
quant_legend <- quant_ranges$label
quant_colors <- quant_colors[1:length(quant_legend)]

if (sum(is.na(county_summary$quant_classes)) > 0) {
  
  quant_colors <- c(quant_colors, "#FFFFFF")
  quant_legend <- c(quant_legend, "No Data")
  
  county_summary$quant_classes <- addNA(county_summary$quant_classes)
}

# Join this data to our shapefiles
small_nys_counties_merged <- merge(small_nys_counties, county_summary, by.x = "NAME", by.y = "NYS_GIS_COUNTY", all.x = T)
small_nys_counties_merged_downstate <- small_nys_counties_merged %>% filter(FIPS_CODE %in% downstate_counties)
small_nys_counties_merged_downstate$quant_classes <- droplevels(small_nys_counties_merged_downstate$quant_classes)

# Need to subset the specific quant_legend and quant_colors for downstate only
# Make a dataframe holding tying our legend label, legend color, and data levels together
quant_class_mapping <- data.frame(quant_classes = levels(county_summary$quant_classes),
                                  quant_legend = quant_legend,
                                  quant_colors = quant_colors)
# Get the specific rows that are present in downstate
downstate_row_ind <- which(quant_class_mapping$quant_classes %in% unique(small_nys_counties_merged_downstate$quant_classes))
downstate_mapping <- quant_class_mapping[downstate_row_ind, ]

mapThemeLabel <- list(
  coord_sf(),
  theme_minimal(),
  theme(axis.line=element_blank(),
        axis.text.x=element_blank(),
        axis.text.y=element_blank(),
        axis.ticks=element_blank(),
        axis.title.x=element_blank(),
        axis.title.y=element_blank(),
        legend.position="bottom",
        legend.key.width=unit(1,"cm"),
        panel.background=element_blank(),
        panel.border=element_blank(),
        panel.grid.major=element_blank(),
        panel.grid.minor=element_blank(),
        plot.background=element_blank()),
  labs(fill = "Cohort Members as % of Statewide Members")
)

nys_map <- ggplot() +
  geom_sf(data = small_nys_counties_merged, size = 0.25, color = "darkgray", aes(fill = quant_classes)) +
  scale_fill_manual(breaks = quant_class_mapping$quant_classes,
                    labels = quant_legend,
                    values = quant_colors,
                    guide=guide_legend(nrow=2)) +
  mapThemeLabel

nys_map_downstate <- ggplot() +
  geom_sf(data = small_nys_counties_merged_downstate, size = 0.25, color = "darkgray", aes(fill = quant_classes)) +
  scale_fill_manual(breaks = downstate_mapping$quant_classes,
                    labels = downstate_mapping$quant_legend, 
                    values = downstate_mapping$quant_colors,
                    guide=guide_legend(nrow=2),
                    drop=F) +
  mapThemeLabel

# Save the plot as a png
ggsave(plot = nys_map, filename = paste0(wd, "/images/nys_map.png"), dpi=500, width = 8.25, height = 6, units = "in")
ggsave(plot = nys_map_downstate, filename = paste0(wd, "/images/nys_map_downstate.png"), dpi=500, width = 8, height = 3.5, units = "in")

# Write the table to excel
appendix_columns <- c("COHORT", "COHORT_MEMBER_MONTHS", "COMPARISON", "COMPARISON_MEMBER_MONTHS", "STATEWIDE")

other_county <- other_county %>%
  summarise_at(
    .vars = appendix_columns,
    .funs = sum) %>%
  mutate(
    County = "OTHER"
  )

map_appendix <- bind_rows(
  county_summary %>% select(c("County"="NYS_GIS_COUNTY", all_of(appendix_columns))),
  other_county
) %>%
  mutate(pct = COHORT / STATEWIDE) %>% 
  arrange(County)

write_appendix_M360(appendix, "4.1 - County Map", map_appendix)

### FIGURE 4.2 - NYS ZIP Map

# Read in the shapefiles and data
small_nys_zips <- st_read("assets/NYS_ZIPs_from_ESRI.shp", quiet = TRUE)
nys_zip_county_xwalk <- read_csv("assets/nys_zip_fips_xwalk.csv", 
                                 col_types = cols(.default = "c"))
# Add the County data to the ZIP data
small_nys_zips <- merge(small_nys_zips, nys_zip_county_xwalk, by.x = "ZIP_CODE", by.y = "ZIP")

# County Summaries
zip_data <- dbGetQuery(HPDW, "{{QRY_ANALYSIS_ZIP_MAP}}")

# Calculate proportions (of statewide)
zip_summary <- zip_data %>%
  mutate(pct = COHORT / STATEWIDE)

n<-5
quant_classes_zip <- classIntervals(filter(zip_summary, COHORT > 0 & STATEWIDE > 0)$pct, n =n, style = "quantile", na.rm=T)
while( length(quant_classes_zip$brks) > length( unique(quant_classes_zip$brks))) {
  n <- n-1
  quant_classes_zip <- classIntervals(filter(zip_summary, COHORT > 0 & STATEWIDE > 0)$pct, n = n, style = "quantile", na.rm=T)
  
}
quant_colors_zip <- c("#d3c5e7", "#A88CCF", "#8961BD", "#603C90", "#301E48")
quant_colors_zip <- quant_colors_zip[1:n]

# Convert the quant_classes_zip to labels that make logical sense
# Lead the classes to get side by side lower and upper bounds
# Drop the NA row, then make our new column to get the final legend value
quant_ranges_zip <- data_frame(lb = pmax(quant_classes_zip$brks, 0) %>% scales::percent(0.01), 
                           ub = pmin(lead(quant_classes_zip$brks), 1) %>% scales::percent(0.01)) %>% 
  na.omit() %>% 
  mutate(label = paste(lb, ub, sep = "-"))

zip_summary <- zip_summary %>%
  mutate(quant_classes_zip = cut(pct, quant_classes_zip$brks, include.lowest = TRUE, ordered_result = TRUE))

quant_legend_zip <- quant_ranges_zip$label

zip_summary$quant_classes_zip <- addNA(zip_summary$quant_classes_zip)
quant_colors_zip <- c(quant_colors_zip, "#FFFFFF")
quant_legend_zip <- c(quant_legend_zip, "No Data")

# Join this data to our shapefiles
small_nys_zips_merged <- merge(small_nys_zips, zip_summary, by.x = "ZIP_CODE", by.y = "MBR_POSTAL_CD", all.x = T)

# Split data by upstate / downstate
upstate_zips <- small_nys_zips_merged
upstate_counties <- small_nys_counties

downstate_zips <- small_nys_zips_merged %>% filter(County_FIPS %in% downstate_counties)
downstate_counties <- small_nys_counties %>% filter(FIPS_CODE %in% downstate_counties)

# Need to subset the specific quant_legend_zip and quant_colors for downstate only
# Make a dataframe holding tying our legend label, legend color, and data levels together
quant_class_mapping_zip <- data.frame(quant_classes_zip = levels(zip_summary$quant_classes_zip),
                                  quant_legend_zip = quant_legend_zip,
                                  quant_colors_zip = quant_colors_zip)
# Get the specific rows that are present in downstate
downstate_row_ind_zip <- which(quant_class_mapping_zip$quant_classes_zip %in% unique(downstate_zips$quant_classes_zip))
downstate_mapping_zip <- quant_class_mapping_zip[downstate_row_ind_zip, ]

nys_map_zip_downstate <- ggplot() +
  #geom_sf(data = downstate_zips, color = "lightgray", size = 0.005, aes(fill = quant_classes_zip)) +
  geom_sf(data = downstate_zips, color = NA, aes(fill = quant_classes_zip)) +
  geom_sf(data = downstate_counties, color = "lightgray", size = 0.75, fill = NA) +
  scale_fill_manual(breaks = downstate_mapping_zip$quant_classes_zip,
                    labels = downstate_mapping_zip$quant_legend_zip, 
                    values = downstate_mapping_zip$quant_colors_zip,
                    guide=guide_legend(nrow=2)) +
  mapThemeLabel

nys_map_zip_upstate <- ggplot() +
  #geom_sf(data = small_nys_zips_merged, color = "lightgray", size = 0.005, aes(fill = quant_classes_zip)) +
  geom_sf(data = upstate_zips, color = NA, aes(fill = quant_classes_zip)) +
  geom_sf(data = upstate_counties, color = "lightgray", size = 0.4, fill = NA) +
  scale_fill_manual(labels = quant_legend_zip, 
                    values = quant_colors_zip,
                    guide=guide_legend(nrow=2)) +
  mapThemeLabel

# Save the plots as a png
ggsave(plot = nys_map_zip_upstate, filename = paste0(wd, "/images/nys_map_zip_upstate.png"), dpi=500, width = 8, height = 6, units = "in")
ggsave(plot = nys_map_zip_downstate, filename = paste0(wd, "/images/nys_map_zip_downstate.png"), dpi=500, width = 8, height = 4, units = "in")

# Write the table to excel
zip_map_appendix <- zip_summary %>% select(MBR_POSTAL_CD, COHORT, STATEWIDE, pct) %>% mutate_if(is.double, as.numeric) %>% arrange(MBR_POSTAL_CD)

write_appendix_M360(appendix, "4.2 - ZIP Map", zip_map_appendix)


### TABLE 4.3 - RATE SETTING REGIONS

# Make Rate Setting Region Table
# Add the region info, group by regions, pivot wider, and compute the proportion of SW by region
fCollapse <- function(data) {
  data %>%
    summarize_at(
      .vars = vars("COHORT", "COHORT_MEMBER_MONTHS", "COMPARISON", "COMPARISON_MEMBER_MONTHS", "STATEWIDE"),
      .funs = sum
    ) %>%
    mutate(
      pct_sw = COHORT / STATEWIDE,
      cohort_pct = COHORT / sum(COHORT, na.rm = TRUE),
      sw_pct = STATEWIDE / sum(STATEWIDE, na.rm = TRUE)
    )
}

region_summary <- county_data %>%
  left_join(county_xwalk, by = "MBR_FISCAL_COUNTY") %>%
  group_by(DFRS_REGION) %>%
  fCollapse

totals <- region_summary %>%
  fCollapse %>% 
  mutate(DFRS_REGION = "Total")

region_summary <- bind_rows(region_summary, totals) %>%
  select(DFRS_REGION, COHORT, cohort_pct, STATEWIDE, sw_pct, pct_sw) %>% 
  mutate(
    cohort_pct = if_else(COHORT < 30, "", scales::percent_format(accuracy = 1)(cohort_pct)),
    COHORT = if_else(COHORT < 30, "< 30", scales::comma_format()(as.numeric(COHORT)))
  )

# Set the int64 columns to numeric
region_summary$STATEWIDE <- as.numeric(region_summary$STATEWIDE)

# Build region summary table
region_summary %>%
  gt() %>%
  cols_label(DFRS_REGION = "Region",
             COHORT = "Cohort Member Count",
             cohort_pct = "% Cohort Members",
             STATEWIDE = "Statewide Member Count",
             sw_pct = "% Statewide Members",
             pct_sw = "Ratio Cohort / Statewide") %>%
  fmt_percent(
    # Set the columns that are percentages
    columns = vars(sw_pct, pct_sw), decimals = 0) %>%
  fmt_number(
    # Set the numeric columns
    columns = vars(STATEWIDE), decimals = 0) %>%
  tab_style(
    # Set the vertical lines around the first column
    style = list(cell_borders(sides = c("left", "right"), color = "#d6dadc", style = "solid", weight = px(2))),
    locations = list(cells_body(columns = vars(DFRS_REGION), rows = everything()),
                     cells_column_labels(columns = vars(DFRS_REGION)))) %>%
  tab_style(
    # Set the vertical line around the right side of the last column
    style = list(cell_borders(sides = "right", color = "#d6dadc", style = "solid", weight = px(2))),
    locations = list(cells_body(columns = vars(pct_sw), rows = everything()),
                     cells_column_labels(columns = vars(pct_sw)))) %>%
  tab_style(
    # Bold Column Headers
    style = list(cell_text(weight = "bold")),
    locations = list(cells_column_labels(columns = everything()))
  ) %>% 
  tab_style(
    # Bold Total Row
    style = list(cell_text(weight = "bold")),
    location = list(cells_body(columns = everything(), rows = 11))
  ) %>% 
  cols_width(
    vars(DFRS_REGION) ~ px(150),
    vars(COHORT) ~ px(125),
    vars(cohort_pct) ~ px(100),
    vars(STATEWIDE) ~ px(150),
    vars(sw_pct) ~ px(120),
    vars(pct_sw) ~ px(125)
  ) %>%
  cols_align(align="right", columns = c("COHORT", "cohort_pct")) %>%
  # Write out to png
  gtsave(paste0(wd,"/images/region_summary_table.html"))

# Write the table to excel
write_appendix_M360(appendix, "4.3 - Region Summary", region_summary)

{% if debug==False %}

},
error = function(e){message("ERROR:", e)}
#warning = function(w){message("WARNING:", w)}
)
{% endif %}

{% if debug==False %}
tryCatch({
{% endif %}

#################################################################
### SECTION 5: EFFICIENCY/PREVENTABLE VIEWS


### FIGURE 5.1 - Efficiency by Category of Service

#Assemble data

cos_eff_df <- dbGetQuery(HPDW, "{{QRY_ANALYSIS_EFFICIENCY_COS}}")

cos_eff_df <- bind_rows(
  cos_eff_df %>% mutate(cos = "Emergency") %>% select(GROUP, cos, Actual = ACT_ER_AMT, Expected = EXP_ER_AMT),
  cos_eff_df %>% mutate(cos = "Inpatient") %>% select(GROUP, cos, Actual = ACT_IP_ADMIT_AMT, Expected = EXP_IP_ADMIT_AMT),
  cos_eff_df %>% mutate(cos = "Outpatient") %>% select(GROUP, cos, Actual = ACT_OUTPAT_AMT, Expected = EXP_OUTPAT_AMT),
  cos_eff_df %>% mutate(cos = "Pharmacy") %>% select(GROUP, cos, Actual = ACT_PHARM_AMT, Expected = EXP_PHARM_AMT),
  cos_eff_df %>% mutate(cos = "Professional") %>% select(GROUP, cos, Actual = ACT_PROF_AMT, Expected = EXP_PROF_AMT),
  cos_eff_df %>% mutate(cos = "Skilled Nursing Facility") %>% select(GROUP, cos, Actual = ACT_SNF_AMT, Expected = EXP_SNF_AMT),
  cos_eff_df %>% mutate(cos = "Total") %>% select(GROUP, cos, Actual = ACT_TOT_AMT, Expected = EXP_TOT_AMT)
)

cos_eff_summary <-  cos_eff_df %>% 
                    mutate(efficiency = Actual/Expected) %>% 
                    arrange(GROUP, cos) %>% 
                    rename(Category_of_Service = cos)

no_data_for_duals_msg <- paste("Efficiency data is unreliable for dual eligible members.\n",
                               "This figure is not shown in this dual eligible report.")
                               
if ({{dual_ind}}) {
  cos_eff_plot <- ggplot() +
    annotate("text", x = 0, y = 0, label = no_data_for_duals_msg) +
    theme_void()
} else {
  cos_eff_plot <- ggplot(data=cos_eff_summary %>% filter(GROUP == cohort_name), mapping=aes(x=fct_rev(Category_of_Service),y=efficiency)) +
    geom_bar( stat='identity', width = 0.2, aes(fill = bar_color)) + 
    geom_hline(yintercept = 1, color="#444444", linetype="dashed") + 
    geom_point(data=cos_eff_summary %>% filter(GROUP == comparison_name), mapping = aes(x=Category_of_Service,y=efficiency, color = "#ECDD78"), size=4) + 
    geom_text(aes(label = format(round(efficiency,2), nsmall=2)), position=position_dodge(width=0.9), hjust=-0.9, size=3.5) +
    theme_classic() + 
    ylab("Efficiency") + 
    coord_flip(ylim = c(0.5,(max(cos_eff_summary$efficiency)+0.3))) + 
    scale_fill_discrete(name = "", labels = cohort_name, type = bar_color) +
    scale_color_discrete(name = "", labels = comparison_name, type = dot_color ) +
    theme(axis.title.y = element_blank(), 
          text = element_text(size=12),
          legend.position = "bottom", 
          legend.text = element_text(size = 10)) +
    labs(fill = "" )
}

#Write plot to file
ggsave(plot = cos_eff_plot, filename = paste0(wd, "/images/cos_eff.png"), width = 4, height = 3.5, units = "in", dpi=300)

#Write data to appendix
write_appendix_M360(appendix,"5.1 - Efficiency by CoS", cos_eff_summary)


### FIGURE 5.2 - Efficiency by PPE

#Assemble data
ppe_eff_df <- dbGetQuery(HPDW, "{{QRY_ANALYSIS_EFFICIENCY_PPE}}")

ppe_eff_df <- bind_rows(
  ppe_eff_df %>% mutate(PPE = "PPA") %>% select(GROUP, PPE, Actual = ACT_PPA_AMT, Expected = EXP_PPA_AMT),
  ppe_eff_df %>% mutate(PPE = "PPR") %>% select(GROUP, PPE, Actual = ACT_PPR_AMT, Expected = EXP_PPR_AMT),
  ppe_eff_df %>% mutate(PPE = "PPS") %>% select(GROUP, PPE, Actual = ACT_PPS_ALLOW_AMT, Expected = EXP_PPS_BUDGET_AMT),
  ppe_eff_df %>% mutate(PPE = "PPV") %>% select(GROUP, PPE, Actual = ACT_PPV_AMT, Expected = EXP_PPV_AMT),
)

ppe_eff_summary <-  ppe_eff_df %>% 
                    mutate(efficiency = Actual/Expected) %>% 
                    arrange(GROUP, PPE)

#Create plot
if ({{dual_ind}}) {
  ppe_eff_plot <- ggplot() +
    annotate("text", x = 0, y = 0, label = no_data_for_duals_msg) +
    theme_void()
} else {
  ppe_eff_plot <- ggplot(data=ppe_eff_summary %>% filter(GROUP == cohort_name), mapping=aes(x=fct_rev(PPE),y=efficiency)) +
    geom_bar(stat='identity', width = 0.2, aes(fill = bar_color)) + 
    geom_hline(yintercept = 1, color="#444444", linetype="dashed") + 
    geom_point(data=ppe_eff_summary %>% filter(GROUP == comparison_name), mapping = aes(x=fct_rev(PPE),y=efficiency, color = "#ECDD78"), size=4) + 
    geom_text(aes(label = format(round(efficiency,2), nsmall=2)), position=position_dodge(width=0.9), hjust=-0.9, size=3.5) +
    theme_classic() + 
    ylab("Efficiency") + 
    coord_flip(ylim = c(0.5,(max(ppe_eff_summary$efficiency)+0.3))) + 
    #scale_y_continuous(limits = c(0.5,max(ppe_eff_summary$efficiency)+0.3)) + 
    scale_fill_discrete(name = "", labels = cohort_name, type = bar_color) +
    scale_color_discrete(name = "", labels = comparison_name, type = dot_color) +
    theme(axis.title.y = element_blank(), 
          text = element_text(size=12),
          legend.position = "bottom", 
          legend.text = element_text(size = 10)) +
    labs(fill = "" )
}

#Write plot to file
ggsave(plot = ppe_eff_plot, filename = paste0(wd, "/images/ppe_eff.png"), width = 4, height = 3.5, units = "in", dpi=300)

#Write data to appendix
write_appendix_M360(appendix,"5.2 - Efficiency by PPE", ppe_eff_summary)


### FIGURE 5.3 - EFFICIENCY BY COVERAGE

coverage_eff_df <- dbGetQuery(HPDW, "{{QRY_ANALYSIS_EFFICIENCY_COVERAGE}}")

coverage_eff_df <- coverage_eff_df %>% mutate(plan_name_tr = str_trunc(plan_name_std,20,'right'))

# At some point plan_name_std became ugly in MA_Enrollment_V3
# this fix here ensures that plans with similar names do not end up
# being duplicated, causing graphical issues -- same issue in 5.4, 5.5
# basically, due to truncated a plan with a similar name but different in
# characters 20+ was causing collisions in the ggplot, this code puts a
# suffix on such duplicative entries
coverage_eff_df <- coverage_eff_df %>% 
  group_by(GROUP, plan_name_tr) %>% 
  mutate(
    x=n(), 
    r=row_number(),
    plan_name_std = if_else(r > 1, paste0(plan_name_tr," (",r,")"), plan_name_tr)
  ) %>% 
  ungroup()

#Select top 10 plans
top10_coverage <- coverage_eff_df %>% 
                  filter(GROUP == cohort_name) %>% 
                  arrange(desc(N_MEMBERS)) %>% 
                  head(10) %>% 
                  select(GROUP, plan_name_std)


coverage_eff_summary <- coverage_eff_df %>% 
                        select(-ACT_IP_ADMIT_CNT,-ACT_PPR_CNT) %>% 
                        filter(plan_name_std %in% top10_coverage$plan_name_std) %>% 
                        mutate(efficiency = Actual/Expected)


#Create plot
if ({{dual_ind}}) {
  coverage_eff_plot <- ggplot() +
    annotate("text", x = 0, y = 0, label = no_data_for_duals_msg) +
    theme_void()
} else {
  coverage_eff_plot <- ggplot(data = coverage_eff_summary %>% filter(GROUP == cohort_name), aes(x = reorder(plan_name_std, efficiency), y = efficiency)) + 
    geom_bar(stat = "identity", width = 0.2, aes(fill = bar_color)) + 
    geom_point(data=coverage_eff_summary %>% filter(GROUP == comparison_name), mapping = aes(x=plan_name_std,y=efficiency, color = dot_color), size=4) + 
    geom_text(aes(label = format(round(efficiency,2), nsmall=2)), position=position_dodge(width=0.9),  hjust=-0.8, size=3.5) +
    theme_classic() + 
    ylab("Efficiency") + 
    coord_flip(ylim = c(0.5,(max(coverage_eff_summary$efficiency)+0.3))) + 
    scale_fill_discrete(name = "", labels = cohort_name, type = bar_color) +
    scale_color_discrete(name = "", labels = comparison_name, type=dot_color) +
    theme(axis.title.y = element_blank(), 
          text = element_text(size=12),
          legend.position = "bottom", 
          legend.text = element_text(size = 10)) +
    labs(fill = "" )
}

#Write plot to file
ggsave(plot = coverage_eff_plot, filename = paste0(wd, "/images/coverage_eff.png"), width = 8, height = 3.5, units = "in", dpi=600)

#Write data to appendix
write_appendix_M360(appendix, "5.3 - Efficiency by Coverage", coverage_eff_summary %>% arrange(GROUP, plan_name_std))

### FIGURE 5.4 - INPATIENT DISCHARGES PER 1,000

#Assemble data
ip_dsch_summary <- coverage_eff_df %>%
                    select(-Actual, -Expected, -ACT_PPR_CNT) %>% 
                    filter(plan_name_std %in% top10_coverage$plan_name_std) %>% 
                    mutate(discharges_per_1000 = (1000*(ACT_IP_ADMIT_CNT/N_MEMBERS))) %>% 
                    arrange(GROUP, desc(N_MEMBERS))
                                    
#Create plot
ip_dsch_plot <- ggplot(data = ip_dsch_summary %>% filter(GROUP == cohort_name), mapping = aes(x = reorder(plan_name_std, discharges_per_1000), y = discharges_per_1000)) +
                geom_bar(stat='identity', width = 0.2, aes(fill = bar_color)) + 
                geom_point(data=ip_dsch_summary %>% filter(GROUP == comparison_name), mapping = aes(x=plan_name_std,y=discharges_per_1000, color = dot_color), size = 4) + 
        				geom_text(aes(label = format(round(discharges_per_1000,1), nsmall=1)), position=position_dodge(width=0.9), hjust=-0.3) +
                theme_classic() + 
                ylab("Discharges per 1,000 Members") +
                scale_y_continuous(limits=c(0,1.2*max(ip_dsch_summary$discharges_per_1000))) + 
                coord_flip() + 
                scale_fill_discrete(name = "", labels = cohort_name, type = bar_color) +
                scale_color_discrete(name = "", labels = comparison_name, type=dot_color) +
                theme(axis.title.y = element_blank(), 
                      text = element_text(size=12),
                      legend.position = "bottom", 
                      legend.text = element_text(size = 10)) +
                labs(fill = "" )
    
#Write plot to file
ggsave(plot = ip_dsch_plot, filename = paste0(wd, "/images/ip_dsch.png"), width = 4, height = 3.5, units = "in", dpi=300)

#Write data to appendix
write_appendix_M360(appendix, "5.4 - IP Discharges", ip_dsch_summary)


### FIGURE 5.5 - % PPR FOR IP DISCHARGES

#Assemble data

ip_ppr_summary <- coverage_eff_df %>% 
                  select(-Actual, -Expected) %>% 
                  filter(plan_name_std %in% top10_coverage$plan_name_std) %>% 
                  mutate(pct = ACT_PPR_CNT/ACT_IP_ADMIT_CNT) %>% 
                  group_by(GROUP) %>% 
                  mutate(ppr_rank = rank(pct), PPR = "PPR")

#Create plot
ip_ppr_plot <- ggplot(data = ip_ppr_summary %>% filter(GROUP == cohort_name), aes(x = reorder(plan_name_std,ppr_rank), y = pct, fill = PPR, label = scales::percent(pct, accuracy = 1))) +
  geom_bar(stat='identity',width = 0.2)+ 
  scale_y_continuous(limits=c(0, NA)) + 
  ylab("% of Total") + 
  geom_text(size = 3.7,position = position_stack(vjust=0.5)) + 
  theme_classic() + 
  scale_fill_manual(values=c(PPR = dot_color), labels = c("PPR")) +
  coord_flip() + 
  theme(axis.title.y = element_blank(), 
        axis.ticks.x = element_blank(),
        axis.text.x = element_blank(),
        text = element_text(size=12),
        legend.position = "bottom", 
        legend.text = element_text(size = 10)) +
  labs(fill = "" )

#Write plot to file
ggsave(plot = ip_ppr_plot, filename = paste0(wd, "/images/ip_ppr.png"), width = 4, height = 3.5, units = "in", dpi=300)

#Write data to appendix
ip_ppr_appendix <- ip_ppr_summary %>%  select(-ppr_rank,-PPR) %>% rename(PPR = pct) %>% arrange(GROUP, desc(ACT_IP_ADMIT_CNT)) %>% ungroup()
write_appendix_M360(appendix, "5.5 - IP % PPR", ip_ppr_appendix)


### FIGURE 5.6 - Top 10 EDCs per 1k

edc_df <- dbGetQuery(HPDW, "{{QRY_ANALYSIS_EDC}}")
                     
top10_edc <-  edc_df %>% 
              filter(GROUP == cohort_name) %>% 
              arrange(desc(N)) %>% 
              head(10) %>% 
              select(EDC_CD)

edc_summary <- edc_df %>% 
  filter(EDC_CD %in% top10_edc$EDC_CD) %>% 
  mutate(per1k = 1000 * N / if_else(GROUP == cohort_name, Cohort_N, Comparison_N),
         edc_label = paste0(EDC_DESC, " (", EDC_CD, ")"))  

# Create plot
# If there is no EDC data (i.e. EDC table not updated
# for the given year, create a blank graphic)
edc_plot_elements <- if(nrow(edc_summary) == 0){
  list(geom_blank())
} else {
  list(
    geom_bar(data = edc_summary %>% filter(GROUP == cohort_name), mapping = aes(x = reorder(edc_label, per1k), y = per1k), stat='identity', width = 0.2, fill = bar_color),
    geom_point(data= edc_summary %>% filter(GROUP == comparison_name), mapping = aes(x=edc_label,y=per1k, color = dot_color), size = 4),
    geom_text(data = edc_summary %>% filter(GROUP == cohort_name), mapping = aes(x = edc_label, y = per1k, label = format(round(per1k,0), nsmall=0)), hjust=-0.3)
  )
}

edc_plot <- ggplot() +
  edc_plot_elements +
  theme_classic() + 
  ylab("EDC per 1,000 Members") +
  scale_y_continuous(limits=c(0,1.2*max(edc_summary$per1k))) + 
  coord_flip() + 
  scale_fill_discrete(name = "", labels = cohort_name, type = bar_color) +
  scale_color_discrete(name = "", labels = comparison_name, type=dot_color) +
  theme(axis.title.y = element_blank(), 
        text = element_text(size=10),
        legend.position = "bottom", 
        legend.text = element_text(size = 10)) +
  labs(fill = "" )

#Write plot to file
ggsave(plot = edc_plot, filename = paste0(wd, "/images/edc_plot.png"), width = 8, height = 4, units = "in", dpi=300)

#Write data to appendix
edc_appendix <- edc_summary %>%  select(-edc_label) %>% arrange(GROUP, desc(per1k))
write_appendix_M360(appendix, "5.6 - 3M EDC", edc_appendix)

cat("\nSection 5 Complete")

{% if debug==False %}

},
error = function(e){message("ERROR:", e)}
#warning = function(w){message("WARNING:", w)}
)
{% endif %}

{% if debug==False %}
tryCatch({
{% endif %}

#################################################################
### SECTION 6: PHARMACY / DRUG VIEWS

###FIGURE 6.1 - Pharmacy Spend by Age Group

rx_age_df <- dbGetQuery(HPDW, "{{QRY_ANALYSIS_RX_AGE}}")

rx_age_df <- rx_age_df %>% 
  group_by(GROUP) %>% 
  summarise(PAID_AMOUNT = sum(PAID_AMOUNT), MEMBER_MONTHS = sum(MEMBER_MONTHS), MEMBERS = sum(MEMBERS)) %>%
  ungroup() %>% 
  mutate(AGE_GROUP = "Total") %>% 
  bind_rows(rx_age_df, .)

rx_age_summary <- rx_age_df %>% 
  mutate(PMPM = PAID_AMOUNT/MEMBER_MONTHS) %>% 
  pivot_wider(id_cols = AGE_GROUP, names_from = "GROUP", values_from = c(PAID_AMOUNT, MEMBERS, PMPM)) %>%
  mutate(tmp = (AGE_GROUP=="Total"))

rx_age_summary[is.na(rx_age_summary)] <- 0

rx_age_summary <- rx_age_summary %>% 
  group_by(tmp) %>% 
  mutate(pct = MEMBERS_Cohort/sum(MEMBERS_Cohort), prop = PMPM_Cohort/PMPM_Comparison) %>%
  ungroup() %>% 
  arrange(AGE_GROUP) %>% 
  select(-tmp)

rx_age_table <- rx_age_summary %>%
  select(AGE_GROUP, pct, PAID_AMOUNT_Cohort, PMPM_Cohort, PAID_AMOUNT_Comparison, PMPM_Comparison, prop) %>% 
  arrange(AGE_GROUP) %>% 
  gt() %>% 
  cols_label(AGE_GROUP = "Age Group",
             pct = str_glue("{cohort_name} % Members"),
             PAID_AMOUNT_Cohort = cohort_name,
             PMPM_Cohort = str_glue("{cohort_name} PMPM"),
             PAID_AMOUNT_Comparison = comparison_name,
             PMPM_Comparison = str_glue("{comparison_name} PMPM"), 
             prop = str_glue("Ratio {cohort_name} / {comparison_name}")) %>% 
  fmt_currency(columns = vars(PAID_AMOUNT_Cohort, PMPM_Cohort, PAID_AMOUNT_Comparison, PMPM_Comparison), decimals=0, currency = "USD") %>%
  fmt_percent(columns=vars(pct), decimals = 0) %>% 
  fmt_number(columns=vars(prop), decimals = 1) %>% 
  tab_style(
    # Set the vertical lines around the first column
    style = list(cell_borders(sides = c("left", "right"), color = "#d6dadc", style = "solid", weight = px(2))),
    locations = list(cells_body(columns = vars(AGE_GROUP), rows = everything()),
                     cells_column_labels(columns = vars(AGE_GROUP)))) %>% 
  tab_style(
    # Set the vertical line around the right side of the last column
    style = list(cell_borders(sides = "right", color = "#d6dadc", style = "solid", weight = px(2))),
    locations = list(cells_body(columns = vars(prop), rows = everything()),
                     cells_column_labels(columns = vars(prop)))) %>%
  tab_style(
    # Bold Column Headers
    style = list(cell_text(weight = "bold")),
    locations = list(cells_column_labels(columns = everything()))
  ) %>% 
  cols_width(
    vars(AGE_GROUP) ~ px(85),
    vars(pct) ~ px(85),
    vars(PAID_AMOUNT_Cohort) ~ px(140),
    vars(PMPM_Cohort) ~ px(90),
    vars(PAID_AMOUNT_Comparison) ~ px(140),
    vars(PMPM_Comparison) ~ px(105),
    vars(prop) ~ px(135)
  ) %>% 
  
  # Write out to png
  gtsave(paste0(wd,"/images/rx_spend_by_age.html"))

write_appendix_M360(appendix, "6.1 - Rx by Age", rx_age_summary)


#FIGURE 6.2: Generic vs. Not Generic

rx_generic_df <- dbGetQuery(HPDW, "{{QRY_ANALYSIS_RX_GENERIC}}")

rx_generic_summary <- rx_generic_df %>% 
  group_by(GROUP) %>% 
  mutate(pct_paid = PAID_AMOUNT/sum(PAID_AMOUNT)) %>% 
  ungroup() %>% 
  arrange(GROUP, BRAND_GENERIC)

rx_generic_plot <- ggplot(data = rx_generic_summary %>% filter(GROUP == cohort_name), mapping = aes(x = reorder(BRAND_GENERIC, pct_paid), y = pct_paid)) +
  geom_bar(stat='identity', width = 0.2, aes(fill = bar_color)) + 
  geom_point(data=rx_generic_summary %>% filter(GROUP == comparison_name), mapping = aes(x=BRAND_GENERIC,y=pct_paid, color = dot_color), size = 4) + 
  geom_text(aes(label = scales::percent(pct_paid, accuracy = 1)), position=position_dodge(width=0.9), hjust=-0.3) +
  theme_classic() + 
  ylab("% of Pharmacy Spend") +
  scale_y_continuous(labels = scales::percent_format(accuracy = 1), limits=c(0,1.05)) + 
  coord_flip() + 
  scale_fill_discrete(name = "", labels = cohort_name, type = bar_color) +
  scale_color_discrete(name = "", labels = comparison_name, type=dot_color) +
  theme(axis.title.y = element_blank(), 
        text = element_text(size=10),
        legend.position = "bottom", 
        legend.text = element_text(size = 10)) +
  labs(fill = "" )

#Write plot to file
ggsave(plot = rx_generic_plot, filename = paste0(wd, "/images/rx_generic.png"), width = 3.9, height = 3.5, units = "in", dpi=300)

#Write data to appendix
write_appendix_M360(appendix, "6.2 - Rx Generic", rx_generic_summary)


#FIGURE 6.3: OTC vs. Not OTC

rx_otc_df <- dbGetQuery(HPDW, "{{QRY_ANALYSIS_RX_OTC}}")

rx_otc_summary <- rx_otc_df %>% 
  group_by(GROUP) %>% 
  mutate(pct_paid = PAID_AMOUNT/sum(PAID_AMOUNT)) %>% 
  ungroup() %>% 
  arrange(GROUP, ITEM_TYPE_DESC)

rx_otc_plot <- ggplot(data = rx_otc_summary %>% filter(GROUP == cohort_name), mapping = aes(x = reorder(ITEM_TYPE_DESC, pct_paid), y = pct_paid)) +
  geom_bar(stat='identity', width = 0.2, aes(fill = bar_color)) + 
  geom_point(data=rx_otc_summary %>% filter(GROUP == comparison_name), mapping = aes(x=ITEM_TYPE_DESC,y=pct_paid, color = dot_color), size = 4) + 
  geom_text(aes(label = scales::percent(pct_paid, accuracy = 1)), position=position_dodge(width=0.9), hjust=-0.3) +
  theme_classic() + 
  ylab("% of Pharmacy Spend") +
  scale_y_continuous(labels = scales::percent_format(accuracy = 1), limits=c(0,1.05)) + 
  coord_flip() + 
  scale_fill_discrete(name = "", labels = cohort_name, type = bar_color) +
  scale_color_discrete(name = "", labels = comparison_name, type=dot_color) +
  theme(axis.title.y = element_blank(), 
        text = element_text(size=10),
        legend.position = "bottom", 
        legend.text = element_text(size = 10)) +
  labs(fill = "" )

#Write plot to file
ggsave(plot = rx_otc_plot, filename = paste0(wd, "/images/rx_otc.png"), width = 3.9, height = 3.5, units = "in", dpi=300)

#Write data to appendix
write_appendix_M360(appendix, "6.3 - Rx OTC", rx_otc_summary)


### FIGURE 6.4 - Top 10 Drug Classes by Paid Amt
# Assemble data

rx_classes_df <- dbGetQuery(HPDW, "{{QRY_ANALYSIS_RX_TOP10_CLASS}}")

rx_classes_summary <- rx_classes_df %>% 
  mutate(ther_class_print = str_c(THER_CLASS_CD_SPCF, ": ", str_trunc(THER_CLASS_SPCF_DESC, 50, "right")),
         MM_denom = ifelse(GROUP == cohort_name, Cohort_MM, Comparison_MM)) %>% 
  mutate(pmpm = PAID_AMOUNT/MM_denom) %>% 
  arrange(GROUP, THER_CLASS_CD_SPCF) %>% 
  mutate(ther_class_print = if_else(is.na(THER_CLASS_CD_SPCF), "Null", ther_class_print))        

#Create plot - 6.4 Top Therapeutic classes for cohort
rx_classes_plot <-   ggplot(data = rx_classes_summary %>% filter(GROUP == cohort_name), mapping = aes(x = reorder(ther_class_print, PAID_AMOUNT), y = PAID_AMOUNT)) +
  geom_bar(stat='identity', width = 0.2, aes(fill = bar_color)) + 
  geom_text(aes(label = scales::dollar(PAID_AMOUNT)), position=position_dodge(width=0.9), hjust=-0.3) +
  theme_classic() + 
  ylab("Pharmacy Spend") +
  scale_y_continuous(labels = scales::dollar_format(), limits=c(0,1.4*max((rx_classes_summary %>% filter(GROUP == cohort_name))$PAID_AMOUNT))) + 
  coord_flip() + 
  scale_fill_discrete(name = "", labels = cohort_name, type = bar_color) +
  theme(axis.title.y = element_blank(), 
        text = element_text(size=10),
        legend.position = "none", 
        legend.text = element_text(size = 10)) +
  labs(fill = "" )

#Write plot to file
ggsave(plot = rx_classes_plot, filename = paste0(wd, "/images/rx_classes.png"), width = 8, height = 3, units = "in", dpi=300)

#Write data to appendix
write_appendix_M360(appendix, "6.4-6.5 - Rx Ther Class", rx_classes_summary)


### Figure 6.5 - Paid PMPM by Therapeutic Class

rx_classes_pmpm_plot <- ggplot(data = rx_classes_summary %>% filter(GROUP == cohort_name), mapping = aes(x = reorder(ther_class_print, PAID_AMOUNT), y = pmpm)) +
  geom_bar(stat='identity', width = 0.2, aes(fill = bar_color)) + 
  geom_point(data=rx_classes_summary %>% filter(GROUP == comparison_name), mapping = aes(x=ther_class_print,y=pmpm, color = dot_color), size = 4) + 
  geom_text(aes(label = scales::dollar(pmpm)), position=position_dodge(width=0.9), hjust=-0.3) +
  theme_classic() + 
  ylab("Pharmacy Spend PMPM") +
  scale_y_continuous(labels = scales::dollar_format(), limits=c(0,1.2*max(rx_classes_summary$pmpm))) + 
  coord_flip() + 
  scale_fill_discrete(name = "", labels = cohort_name, type = bar_color) +
  scale_color_discrete(name = "", labels = comparison_name, type=dot_color) +
  theme(axis.title.y = element_blank(), 
        text = element_text(size=10),
        legend.position = "bottom", 
        legend.text = element_text(size = 10)) +
  labs(fill = "" )

#Write plot to file
ggsave(plot = rx_classes_pmpm_plot, filename = paste0(wd, "/images/rx_classes_pmpm.png"), width = 8, height = 3, units = "in", dpi=300)


### Figures 6.6/6.7 - Rx by Brand Name

### Figure 6.6 - Top Brands for Cohort

rx_brand_df <- dbGetQuery(HPDW, "{{QRY_ANALYSIS_RX_TOP10_BRAND}}")

rx_brand_summary <- rx_brand_df %>% 
  mutate(MM_denom = ifelse(GROUP == cohort_name, Cohort_MM, Comparison_MM)) %>% 
  mutate(pmpm = PAID_AMOUNT/MM_denom) %>% 
  mutate(BRAND_NAME = if_else(is.na(BRAND_NAME), "Null", BRAND_NAME)) %>%
  arrange(GROUP, BRAND_NAME)

#Create plot - 5.6 Top Brand for cohort
rx_brand_plot <- ggplot(data = rx_brand_summary %>% filter(GROUP == cohort_name), mapping = aes(x = reorder(BRAND_NAME, PAID_AMOUNT), y = PAID_AMOUNT)) +
  geom_bar(stat='identity', width = 0.2, aes(fill = bar_color)) + 
  geom_text(aes(label = scales::dollar(PAID_AMOUNT)), position=position_dodge(width=0.9), hjust=-0.3) +
  theme_classic() + 
  ylab("Pharmacy Spend") +
  scale_y_continuous(labels = scales::dollar_format(), limits=c(0,1.4*max((rx_brand_summary %>% filter(GROUP == cohort_name))$PAID_AMOUNT))) + 
  coord_flip() + 
  scale_fill_discrete(name = "", labels = cohort_name, type = bar_color) +
  theme(axis.title.y = element_blank(), 
        text = element_text(size=10),
        legend.position = "none", 
        legend.text = element_text(size = 10)) +
  labs(fill = "" )

#Write plot to file
ggsave(plot = rx_brand_plot, filename = paste0(wd, "/images/rx_brand.png"), width = 8, height = 3, units = "in", dpi=300)

#Write data to appendix
write_appendix_M360(appendix, "6.6-6.7 - Rx Brand Names", rx_brand_summary)


### Figure 6.7 - Paid PMPM by Brand Name 

rx_brand_pmpm_plot <- ggplot(data = rx_brand_summary %>% filter(GROUP == cohort_name), mapping = aes(x = reorder(BRAND_NAME, PAID_AMOUNT), y = pmpm)) +
  geom_bar(stat='identity', width = 0.2, aes(fill = bar_color)) + 
  geom_point(data=rx_brand_summary %>% filter(GROUP == comparison_name), mapping = aes(x=BRAND_NAME,y=pmpm, color = dot_color), size = 4) + 
  geom_text(aes(label = scales::dollar(pmpm)), position=position_dodge(width=0.9), hjust=-0.3) +
  theme_classic() + 
  ylab("Pharmacy Spend PMPM") +
  scale_y_continuous(labels = scales::dollar_format(), limits=c(0,1.2*max(rx_brand_summary$pmpm))) + 
  coord_flip() + 
  scale_fill_discrete(name = "", labels = cohort_name, type = bar_color) +
  scale_color_discrete(name = "", labels = comparison_name, type=dot_color) +
  theme(axis.title.y = element_blank(), 
        text = element_text(size=10),
        legend.position = "bottom", 
        legend.text = element_text(size = 10)) +
  labs(fill = "" )

#Write plot to file
ggsave(plot = rx_brand_pmpm_plot, filename = paste0(wd, "/images/rx_brand_pmpm.png"), width = 8, height = 3, units = "in", dpi=300)


### Figure 6.8 - Top NDCs for Cohort

rx_ndc_df <- dbGetQuery(HPDW, "{{QRY_ANALYSIS_RX_TOP10_NDC}}")

rx_ndc_summary <- rx_ndc_df %>% 
  mutate(ndc_print = str_c(NDC, ": ", str_trunc(DRUG_LBL_NAME, 50, "right")),
         MM_denom = ifelse(GROUP == cohort_name, Cohort_MM, Comparison_MM)) %>% 
  mutate(ndc_print = if_else(NDC == "No NDC Submitted", NDC, ndc_print)) %>% 
  mutate(pmpm = PAID_AMOUNT/MM_denom) %>% 
  arrange(GROUP, NDC)

#Create plot - 6.8 Top NDC for cohort

rx_ndc_plot <- ggplot(data = rx_ndc_summary %>% filter(GROUP == cohort_name), mapping = aes(x = reorder(ndc_print, PAID_AMOUNT), y = PAID_AMOUNT)) +
  geom_bar(stat='identity', width = 0.2, aes(fill = bar_color)) + 
  geom_text(aes(label = scales::dollar(PAID_AMOUNT)), position=position_dodge(width=0.9), hjust=-0.3) +
  theme_classic() + 
  ylab("Pharmacy Spend") +
  scale_y_continuous(labels = scales::dollar_format(), limits=c(0,1.4*max((rx_ndc_summary %>% filter(GROUP == cohort_name))$PAID_AMOUNT))) + 
  coord_flip() + 
  scale_fill_discrete(name = "", labels = cohort_name, type = bar_color) +
  theme(axis.title.y = element_blank(), 
        text = element_text(size=10),
        legend.position = "none", 
        legend.text = element_text(size = 10)) +
  labs(fill = "" )

#Write plot to file
ggsave(plot = rx_ndc_plot, filename = paste0(wd, "/images/rx_ndc.png"), width = 8, height = 3, units = "in", dpi=300)

#Write data to appendix
write_appendix_M360(appendix, "6.8-6.9 - Rx NDC", rx_ndc_summary)


### Figure 6.9 - Paid PMPM by NDC 

rx_ndc_pmpm_plot <- ggplot(data = rx_ndc_summary %>% filter(GROUP == cohort_name), mapping = aes(x = reorder(ndc_print, PAID_AMOUNT), y = pmpm)) +
  geom_bar(stat='identity', width = 0.2, aes(fill = bar_color)) + 
  geom_point(data=rx_ndc_summary %>% filter(GROUP == comparison_name), mapping = aes(x=ndc_print,y=pmpm, color = dot_color), size = 4) + 
  geom_text(aes(label = scales::dollar(pmpm)), position=position_dodge(width=0.9), hjust=-0.3) +
  theme_classic() + 
  ylab("Pharmacy Spend PMPM") +
  scale_y_continuous(labels = scales::dollar_format(), limits=c(0,1.2*max(rx_ndc_summary$pmpm))) + 
  coord_flip() + 
  scale_fill_discrete(name = "", labels = cohort_name, type = bar_color) +
  scale_color_discrete(name = "", labels = comparison_name, type=dot_color) +
  theme(axis.title.y = element_blank(), 
        text = element_text(size=10),
        legend.position = "bottom", 
        legend.text = element_text(size = 10)) +
  labs(fill = "" )

#Write plot to file
ggsave(plot = rx_ndc_pmpm_plot, filename = paste0(wd, "/images/rx_ndc_pmpm.png"), width = 8, height = 3, units = "in", dpi=300)

cat("\nSection 6 Complete")

{% if debug==False %}

},
error = function(e){message("ERROR:", e)}
#warning = function(w){message("WARNING:", w)}
)
{% endif %}

{% if debug==False %}
tryCatch({
{% endif %}

#################################################################
### SECTION 7: LAB VIEWS


#Figure 7.1 - Lab Summary 
lab_df <- dbGetQuery(HPDW, "{{QRY_ANALYSIS_LAB_SUMMARY}}")

lab_summary <- lab_df %>% 
  mutate_if(is.integer64, as.numeric) %>% 
  mutate(
    '1_CLAIM_COUNT' = CLAIM_COUNT,
    '2_CLAIM_PER' = CLAIM_COUNT/if_else(GROUP == "Cohort", Cohort_N, Comparison_N),
    '3_PAID_AMT' = PAID_AMT,
    '4_PMPM' = PAID_AMT/if_else(GROUP == "Cohort", Cohort_MM, Comparison_MM)) %>% 
  select(., -c(CLAIM_COUNT, PAID_AMT)) %>% 
  pivot_longer(cols = -GROUP, names_to = "Measure", values_to = "Value") %>% 
  pivot_wider(id_cols = Measure, names_from = GROUP, values_from = Value) %>% 
  select(Measure, Cohort, Comparison) %>%
  arrange(Measure)

lab_summary$Measure <- c("Total Lab Claims",
                         "Lab Claims Per Member", 
                         "Total Spend from Lab Claims", 
                         "PMPM from Lab Claims")


lab_summary_table <- lab_summary %>% gt() %>% 
  cols_label(Measure = "Measure", 
             Cohort = cohort_name, 
             Comparison = comparison_name) %>% 
  fmt_number(columns = vars(Cohort, Comparison), rows = 1, decimals=0) %>% 
  fmt_number(columns = vars(Cohort, Comparison), rows = 2, decimals=1) %>%
  fmt_currency(columns = vars(Cohort, Comparison), rows = 3:4, decimals=0, currency = "USD") %>% 
  tab_style(
    # Set the vertical lines around the first column
    style = list(cell_borders(sides = c("left", "right"), color = "#d6dadc", style = "solid", weight = px(2))),
    locations = list(cells_body(columns = vars(Measure), rows = everything()),
                     cells_column_labels(columns = vars(Measure)))) %>% 
  tab_style(
    # Set the vertical line around the right side of the last column
    style = list(cell_borders(sides = "right", color = "#d6dadc", style = "solid", weight = px(2))),
    locations = list(cells_body(columns = vars(Comparison), rows = everything()),
                     cells_column_labels(columns = vars(Comparison)))) %>%
  tab_style(
    # Bold Column Headers
    style = list(cell_text(weight = "bold")),
    locations = list(cells_column_labels(columns = everything()))
  ) %>% 
  
  cols_width(
    vars(Measure) ~ px(320),
    vars(Cohort) ~ px(230),
    vars(Comparison) ~ px(230),
  ) %>% 
  # Write out to png
  gtsave(paste0(wd,"/images/lab_summary_table.html"))

write_appendix_M360(appendix, "7.1 - Lab Summary", lab_summary)

### FIGURE 7.2 - Lab Code Category

lab_code_cat_df <- dbGetQuery(HPDW, "{{QRY_ANALYSIS_LAB_CD_CAT}}")

lab_code_cat_summary <- lab_code_cat_df %>% 
  mutate(CODE_CATEGORY_TR = str_trunc(CODE_CATEGORY, 50, "right")) %>%
  group_by(GROUP, CODE_CATEGORY_TR) %>% 
  mutate(
    x=n(), 
    r=row_number(),
    CODE_CATEGORY = if_else(r > 1, paste0(CODE_CATEGORY_TR," (",r,")"), CODE_CATEGORY_TR)
  ) %>% 
  ungroup() %>%
  mutate(
    pmpm = PAID_AMOUNT/if_else(GROUP == cohort_name, Cohort_MM, Comparison_MM)
  ) %>% 
  arrange(GROUP, CODE_CATEGORY)

#Create plot - 6.3 Top proc for cohort
lab_code_cat_plot <- ggplot(data = lab_code_cat_summary %>% filter(GROUP == cohort_name), mapping = aes(x = reorder(CODE_CATEGORY, PAID_AMOUNT), y = PAID_AMOUNT)) +
  geom_bar(stat='identity', width = 0.2, aes(fill = bar_color)) +
  geom_text(aes(label = scales::dollar(PAID_AMOUNT)), position=position_dodge(width=0.9), hjust=-0.3) +
  theme_classic() +
  ylab("Lab Spend") +
  scale_y_continuous(labels = scales::dollar_format(), limits=c(0,1.4*max((lab_code_cat_summary %>% filter(GROUP == cohort_name))$PAID_AMOUNT))) +
  coord_flip() +
  scale_fill_discrete(name = "", labels = cohort_name, type = bar_color) +
  theme(axis.title.y = element_blank(),
        text = element_text(size=9.5),
        legend.position = "bottom",
        legend.text = element_text(size = 9.5)) +
  labs(fill = "" )

#Write plot to file
ggsave(plot = lab_code_cat_plot, filename = paste0(wd, "/images/lab_code_cat.png"), width = 8, height = 3, units = "in", dpi=300)

#Write data to appendix
write_appendix_M360(appendix, "7.2-7.3 - Lab Code Category", lab_code_cat_summary)


### FIGURE 7.3: PMPM by Code Category
lab_code_pmpm_plot <- ggplot(data = lab_code_cat_summary %>% filter(GROUP == cohort_name), mapping = aes(x = reorder(CODE_CATEGORY, PAID_AMOUNT), y = pmpm)) +
  geom_bar(stat='identity', width = 0.2, aes(fill = bar_color)) + 
  geom_point(data=lab_code_cat_summary %>% filter(GROUP == comparison_name), mapping = aes(x=CODE_CATEGORY,y=pmpm, color = dot_color), size = 4) + 
  geom_text(aes(label = scales::dollar(pmpm)), position=position_dodge(width=0.9), hjust=-0.3) +
  theme_classic() + 
  ylab("Lab Spend PMPM") +
  scale_y_continuous(labels = scales::dollar_format(), limits=c(0,1.2*max(lab_code_cat_summary$pmpm))) + 
  coord_flip() + 
  scale_fill_discrete(name = "", labels = cohort_name, type = bar_color) +
  scale_color_discrete(name = "", labels = comparison_name, type=dot_color) +
  theme(axis.title.y = element_blank(), 
        text = element_text(size=10),
        legend.position = "bottom", 
        legend.text = element_text(size = 10)) +
  labs(fill = "" )

#Write plot to file
ggsave(plot = lab_code_pmpm_plot, filename = paste0(wd, "/images/lab_code_cat_pmpm.png"), width = 8, height = 3, units = "in", dpi=300)


### FIGURE 7.4 - Top Procedure Codes

lab_proc_df <- dbGetQuery(HPDW, "{{QRY_ANALYSIS_LAB_TOP10_PROC}}")

lab_proc_summary <- lab_proc_df %>% 
  mutate(proc_cd_print = str_c(PROCEDURE_CODE, ": ", str_trunc(PROC_CD_DESC, 50, "right")),
         pmpm = PAID_AMOUNT/if_else(GROUP == cohort_name, Cohort_MM, Comparison_MM)) %>% 
  arrange(GROUP, PROCEDURE_CODE)

#Create plot - 7.4 Top proc for cohort
lab_proc_plot <- ggplot(data = lab_proc_summary %>% filter(GROUP == cohort_name), mapping = aes(x = reorder(proc_cd_print, PAID_AMOUNT), y = PAID_AMOUNT)) +
  geom_bar(stat='identity', width = 0.2, aes(fill = bar_color)) +
  geom_text(aes(label = scales::dollar(PAID_AMOUNT)), position=position_dodge(width=0.9), hjust=-0.3) +
  theme_classic() +
  ylab("Lab Spend") +
  scale_y_continuous(labels = scales::dollar_format(), limits=c(0,1.4*max((lab_proc_summary %>% filter(GROUP == cohort_name))$PAID_AMOUNT))) +
  coord_flip() +
  scale_fill_discrete(name = "", labels = cohort_name, type = bar_color) +
  theme(axis.title.y = element_blank(),
        text = element_text(size=10),
        legend.position = "bottom",
        legend.text = element_text(size = 10)) +
  labs(fill = "" )

#Write plot to file
ggsave(plot = lab_proc_plot, filename = paste0(wd, "/images/lab_proc.png"), width = 8, height = 3, units = "in", dpi=300)

#Write data to appendix
write_appendix_M360(appendix, "7.4-7.5 - Lab Procedures", lab_proc_summary)


### FIGURE 7.5 - PMPM by Proc Code
lab_proc_pmpm_plot <- ggplot(data = lab_proc_summary %>% filter(GROUP == cohort_name), mapping = aes(x = reorder(proc_cd_print, PAID_AMOUNT), y = pmpm)) +
  geom_bar(stat='identity', width = 0.2, aes(fill = bar_color)) + 
  geom_point(data=lab_proc_summary %>% filter(GROUP == comparison_name), mapping = aes(x=proc_cd_print,y=pmpm, color = dot_color), size = 4) + 
  geom_text(aes(label = scales::dollar(pmpm)), position=position_dodge(width=0.9), hjust=-0.3) +
  theme_classic() + 
  ylab("Lab Spend PMPM") +
  scale_y_continuous(labels = scales::dollar_format(), limits=c(0,1.2*max(lab_proc_summary$pmpm))) + 
  coord_flip() + 
  scale_fill_discrete(name = "", labels = cohort_name, type = bar_color) +
  scale_color_discrete(name = "", labels = comparison_name, type=dot_color) +
  theme(axis.title.y = element_blank(), 
        text = element_text(size=10),
        legend.position = "bottom", 
        legend.text = element_text(size = 10)) +
  labs(fill = "" )

#Write plot to file
ggsave(plot = lab_proc_pmpm_plot, filename = paste0(wd, "/images/lab_proc_pmpm.png"), width = 8, height = 3, units = "in", dpi=300)

## NEW TABLES 7.6/7.7- TOP CODES BY MC/FFS

lab_mcffs_df <- dbGetQuery(HPDW, "{{QRY_ANALYSIS_LAB_MC_FFS}}")

lab_mcffs_summary <- lab_mcffs_df %>% 
  group_by(GROUP, CLAIM_SOURCE) %>% 
  mutate(pct = TOT_PD/sum(TOT_PD),
         paid_per_claim = TOT_PD/CLAIMS,
         proc_cd_print = paste0(PROCEDURE_CODE, ": ", str_trunc(PROC_CD_DESC, 50, 'right'))) %>%
  ungroup() %>% 
  mutate_if(is.double, as.numeric) %>% 
  arrange(GROUP, CLAIM_SOURCE, PROCEDURE_CODE)

lab_top_codes_table <- function(df, cohort, claim_source, figname) {
  
  #Filter/Arrange Data Frame
  df <- df %>% 
    filter(GROUP == cohort, CLAIM_SOURCE == claim_source) %>% 
    arrange(CODE_RANK) %>% 
    select(CODE_RANK, proc_cd_print, CLAIMS, TOT_PD, paid_per_claim)
  
  #Create Table
  lab_table <- df %>%
    gt() %>% 
    cols_label(CODE_RANK = "#",
               proc_cd_print = "Procedure Code", 
               CLAIMS = "Claims", 
               TOT_PD = "Total Spend",
               paid_per_claim = "Spend Per Claim") %>% 
    fmt_currency(columns = vars(TOT_PD), decimals = 0, currency = "USD") %>% 
    fmt_currency(columns = vars(paid_per_claim), decimals = 2, currency = "USD") %>% 
    fmt_number(columns = vars(CLAIMS), decimals = 0) %>% 
    tab_style(
      # Set the vertical lines around the first column
      style = list(
        cell_borders(sides = c("left", "right"), color = "#d6dadc", style = "solid", weight = px(2))
      ),
      locations = list(cells_body(columns = vars(CODE_RANK, proc_cd_print), rows = everything()),
                       cells_column_labels(columns = vars(CODE_RANK, proc_cd_print)))
    )%>% 
    tab_style(
      # Set the vertical line around the right side of the last column
      style = list(cell_borders(sides = "right", color = "#d6dadc", style = "solid", weight = px(2))),
      locations = list(cells_body(columns = vars(paid_per_claim), rows = everything()),
                       cells_column_labels(columns = vars(paid_per_claim)))) %>%
    tab_style(
      # Bold Column Headers
      style = list(cell_text(weight = "bold")),
      locations = list(cells_column_labels(columns = everything()))
    ) %>% 
    cols_width(
      vars(CODE_RANK) ~ px(30),
      vars(proc_cd_print) ~ px(340),
      vars(CLAIMS) ~ px(115),
      vars(TOT_PD) ~ px(135),
      vars(paid_per_claim) ~ px(160),
    ) %>% 
    gtsave(paste0(wd, "/images/", figname, ".html"))
}

lab_top_codes_table(lab_mcffs_summary, cohort_name, "MC", "lab_top_codes_mc")
lab_top_codes_table(lab_mcffs_summary, cohort_name, "FFS", "lab_top_codes_ffs")

write_appendix_M360(appendix, "7.6-7.7 - Top Lab Codes MC-FFS", lab_mcffs_summary)


### FIGURE 7.8 - Claims by Place of Service

lab_place_df <- dbGetQuery(HPDW, "{{QRY_ANALYSIS_LAB_PLACE}}")


lab_place_df  <- lab_place_df %>% replace(is.na(.), "NULL") %>% 
  group_by(GROUP) %>% 
  mutate(pct = N_CLAIMS/sum(N_CLAIMS),
         pl_srv_print = str_c(PL_OF_SRV_BILL_TYPE_CD, ": ", str_trunc(PL_OF_SRV_DESC, 50, "right"))) %>% 
  mutate(pl_srv_print = if_else(PL_OF_SRV_BILL_TYPE_CD == 'NULL', "No Place of Service Submitted", pl_srv_print)) %>% 
  ungroup()

top5_place <- lab_place_df %>% 
  filter(GROUP == "Cohort") %>%
  arrange(desc(N_CLAIMS)) %>% 
  head(5) %>% 
  select(PL_OF_SRV_BILL_TYPE_CD)

lab_place_summary <- bind_rows(

  #Top 5 place of service
  lab_place_df %>% 
    filter(PL_OF_SRV_BILL_TYPE_CD %in% top5_place$PL_OF_SRV_BILL_TYPE_CD) %>% 
    select(GROUP, pl_srv_print, N_CLAIMS, pct)
  ,
  
  #OTHER (all besides top 5)
  lab_place_df %>% 
    filter(!PL_OF_SRV_BILL_TYPE_CD %in% top5_place$PL_OF_SRV_BILL_TYPE_CD) %>% 
    group_by(GROUP) %>% 
    summarise(GROUP = max(GROUP), pl_srv_print = 'OTHER', N_CLAIMS = sum(N_CLAIMS), pct = sum(pct)) %>% 
    ungroup()
  ,
  #TOTAL 
  
  lab_place_df %>% 
    group_by(GROUP) %>% 
    summarise(GROUP = max(GROUP), pl_srv_print = 'TOTAL', N_CLAIMS = sum(N_CLAIMS), pct = sum(pct)) %>% 
    ungroup()
) %>%
  pivot_wider(id_cols = pl_srv_print, names_from = GROUP, values_from = c(N_CLAIMS, pct)) %>% 
  mutate(rank = if_else(pl_srv_print %in% c("OTHER", "TOTAL"), if_else(pl_srv_print == "TOTAL", -1, 0), 1)) %>% 
  arrange(desc(rank), desc(N_CLAIMS_Cohort)) %>% 
  mutate_if(is.integer64, as.numeric) %>% 
  select(pl_srv_print, N_CLAIMS_Cohort, pct_Cohort, N_CLAIMS_Comparison, pct_Comparison)

lab_place_table <- lab_place_summary %>%
  gt() %>%
  cols_label(pl_srv_print = "Place of Service",
             N_CLAIMS_Cohort = str_glue("{cohort_name} Claims"),
             pct_Cohort = str_glue("% of {cohort_name}"),
             N_CLAIMS_Comparison = str_glue("{comparison_name} Claims"),
             pct_Comparison = str_glue("% of {comparison_name}")) %>%
  fmt_percent(
    # Set the columns that are percentages
    columns = vars(pct_Cohort, pct_Comparison), decimals = 0) %>%
  fmt_number(
    # Set the numeric columns
    columns = vars(N_CLAIMS_Cohort, N_CLAIMS_Comparison), decimals = 0) %>%
  tab_style(
    # Set the vertical lines around the first column
    style = list(cell_borders(sides = c("left", "right"), color = "#d6dadc", style = "solid", weight = px(2))),
    locations = list(cells_body(columns = vars(pl_srv_print), rows = everything()),
                     cells_column_labels(columns = vars(pl_srv_print)))) %>%
  tab_style(
    # Set the vertical line around the right side of the last column
    style = list(cell_borders(sides = "right", color = "#d6dadc", style = "solid", weight = px(2))),
    locations = list(cells_body(columns = vars(pct_Comparison), rows = everything()),
                     cells_column_labels(columns = vars(pct_Comparison)))) %>%
  tab_style(
    # Bold Column Headers
    style = list(cell_text(weight = "bold")),
    locations = list(cells_column_labels(columns = everything()))
  ) %>% 
  tab_style(
    #Bold Total Row
    style = list(cell_text(weight = "bold")),
    location = list(cells_body(columns = everything(), rows = 7))
  ) %>% 
  cols_width(
    vars(pl_srv_print) ~ px(225),
    vars(N_CLAIMS_Cohort) ~ px(135),
    vars(pct_Cohort) ~ px(120),
    vars(N_CLAIMS_Comparison) ~ px(150),
    vars(pct_Comparison) ~ px(150),
  ) %>%
  
  # Write out to png
  gtsave(paste0(wd,"/images/lab_place_table.html"))  
  
  
write_appendix_M360(appendix, "7.8 - Lab Place of Service", lab_place_df)
cat("\nSection 7 Complete")

{% if debug==False %}

},
error = function(e){message("ERROR:", e)}
#warning = function(w){message("WARNING:", w)}
)
{% endif %}

{% if debug==False %}
tryCatch({
{% endif %}

########################################
### SECTION 8: QUALITY (CDM MEASURES)

#Import CDM Crosswalk
cdm_cw <- read.csv("assets/CDM_crosswalk.csv", header=TRUE, sep=',', encoding='UTF-8') %>% rename("Measure Name" = !!names(.[1]))

#Raw counts of measure values by msr_comp_id
cdm_raw <- dbGetQuery(HPDW, "{{QRY_ANALYSIS_QUALITY}}")

#Attach additional denominators where needed and pivot back to long
soft_mutate <- function(df) {
  
  renames <- c("AMM-ACUTE-DEN" = "AMM-DEN",
               "FUA-30-DEN" = "FUA-DEN",
               "FUH30V2-DEN" = "FUHV2-DEN",
               "FUM-30-DEN" = "FUM-DEN",
               "IETV2-INI-DEN" = "IETV2-DEN",
               "MMA75-DEN" = "MMA-DEN",
               "PPC-PRECAR-DEN" = "PPC-DEN")
  
  renames <- data.frame(
    MSR_COMP_ID_NEW = names(renames),
    MSR_COMP_ID = as.character(renames)
  )

  df.new <- df %>%
    left_join(renames, by="MSR_COMP_ID") %>%
    mutate(
      MSR_COMP_ID = if_else(!is.na(MSR_COMP_ID_NEW), MSR_COMP_ID_NEW, MSR_COMP_ID)
    ) %>%
    filter(!is.na(MSR_COMP_ID_NEW)) %>%
    select(GROUP, MSR_COMP_ID, MSR_VAL)
  
  bind_rows(
    df,
    df.new
  )
}

#Join CDM reference information to measures values and create numerator and denominator
cdm_w_ref <- cdm_raw %>%
  complete(GROUP, MSR_COMP_ID, fill = list(MSR_VAL = 0)) %>%  
  soft_mutate() %>%
  left_join(cdm_cw, by = "MSR_COMP_ID") %>%
  mutate_if(is.integer64, as.numeric) %>%
  mutate(
    MSR_NUM = if_else(Numerator==1, MSR_VAL, 0),
    MSR_DEN = if_else(Numerator==0, MSR_VAL, 0)
  )

#Group by Measure and summarize into MSR_NUM,MSR_DEN
cdm_summary <- cdm_w_ref %>%
  group_by(GROUP, MSR_ID_SUBCAT) %>%
  summarise(
    "MSR_NAME" = max(`MSR_NAME_PRINT`),
    "MSR_CATG_DESC" = max(MSR_CATG_DESC),
    "MSR_UNIT" = max(MSR_UNIT),
    "MSR_NUM" = sum(MSR_NUM),
    "MSR_DEN" = sum(MSR_DEN),
    "INVERT" = max(INVERT)
  ) %>%
  ungroup() %>%
  mutate(
    MSR_RESULT = MSR_UNIT*MSR_NUM/MSR_DEN
  )

required_qm_columns <- c(
  MSR_NUM_COHORT = 0, 
  MSR_DEN_COHORT = 0, 
  MSR_RESULT_COHORT = 0,
  MSR_NUM_COMPARISON = 0,
  MSR_DEN_COMPARISON = 0,
  MSR_RESULT_COMPARISON = 0
)
  
cdm_table <- cdm_summary %>%
  pivot_wider(
    id_cols=c(MSR_NAME, MSR_CATG_DESC, INVERT),
    names_from=GROUP,
    values_from = c(MSR_NUM, MSR_DEN, MSR_RESULT)
  ) %>%
  unchop(everything()) %>%
  add_column(!!!required_qm_columns[!(names(required_qm_columns) %in% names(.))]) %>%
  rename(
    "Measure Name" = MSR_NAME,
    "Measure Category" = MSR_CATG_DESC,
    "Cohort Numerator" = MSR_NUM_COHORT,
    "Cohort Denominator" = MSR_DEN_COHORT,
    "Cohort Result" = MSR_RESULT_COHORT,
    "Statewide Numerator" = MSR_NUM_COMPARISON,
    "Statewide Denominator" = MSR_DEN_COMPARISON,
    "Statewide Result" = MSR_RESULT_COMPARISON
  ) %>%
  select("Measure Category", everything()) %>%
  mutate_if(is.double, as.numeric)

create_cdm_table <- function(data, domain, figname){
  suppression_threshold <- 30
  suppression_string <- "<30"
  
  x <- data %>% filter(`Measure Category` == domain) %>% nrow
  if (x == 0) {
    return()
  }
  
  cdm_table_print <- data %>% filter(`Measure Category`==domain) %>% select(-`Measure Category`) %>% 
    select(
      `Measure Name`,
      `INVERT`,
      `Cohort Numerator`,
      `Cohort Denominator`,
      `Cohort Result`,
      `Statewide Numerator`,
      `Statewide Denominator`,
      `Statewide Result`,
    ) %>% 
    mutate(
            INVERT = case_when(
              INVERT == "Y" ~ "\u25BC",
              INVERT == "N" ~ "\u25B2",
              T ~ "\u25A0"
            ),
           `Cohort Result` = if_else(`Cohort Numerator` < suppression_threshold, "", scales::comma_format(accuracy = 0.1)(`Cohort Result`)),
           `Statewide Result` = if_else(`Statewide Numerator` < suppression_threshold, "", scales::comma_format(accuracy = 0.1)(`Statewide Result`)),
           `Cohort Numerator` = if_else(`Cohort Numerator` < suppression_threshold, suppression_string, scales::comma_format(accuracy = 1)(`Cohort Numerator`)),
           `Cohort Denominator` = if_else(`Cohort Denominator` < suppression_threshold, suppression_string, scales::comma_format(accuracy = 1)(`Cohort Denominator`)),
           `Statewide Numerator` = if_else(`Statewide Numerator` < suppression_threshold, suppression_string, scales::comma_format(accuracy = 1)(`Statewide Numerator`)),
           `Statewide Denominator` = if_else(`Statewide Denominator` < suppression_threshold, suppression_string, scales::comma_format(accuracy = 1)(`Statewide Denominator`))) %>% 
    gt() %>%
    cols_label(`Measure Name` = "Measure Name",
               `Cohort Numerator` = "{{cohort_name}} Num",
               `Cohort Denominator` = "{{cohort_name}} Den",
               `Cohort Result` = "{{cohort_name}} Result",
               `INVERT` = "",
               `Statewide Numerator` = "{{comparison_name}} Num",
               `Statewide Denominator` = "{{comparison_name}} Den",
               `Statewide Result` = "{{comparison_name}} Result") %>%
    tab_style(
      # Set the vertical lines around the first column
      style = list(cell_borders(sides = c("left", "right"), color = "#d6dadc", style = "solid", weight = px(2))),
      locations = list(cells_body(columns = vars(`Measure Name`, `INVERT`), rows = everything()),
                       cells_column_labels(columns = vars(`Measure Name`, `INVERT`)))) %>%
    tab_style(
      # Set the vertical line around the right side of the last column
      style = list(cell_borders(sides = "right", color = "#d6dadc", style = "solid", weight = px(2))),
      locations = list(cells_body(columns = vars(`Statewide Result`), rows = everything()),
                       cells_column_labels(columns = vars(`Statewide Result`)))) %>%
    tab_style(
      # Bold Column Headers
      style = list(cell_text(weight = "bold")),
      locations = list(cells_column_labels(columns = everything()))
    ) %>% 
    cols_align(align="right") %>% 
    cols_align(align="left", columns = c("Measure Name")) %>% 
    cols_align(align="center", columns = c("INVERT")) %>% 
    cols_width(
      vars(`Measure Name`) ~ px(225),
      vars(`Cohort Numerator`) ~ px(75),
      vars(`Cohort Denominator`) ~ px(75),
      vars(`Cohort Result`) ~ px(75),
      vars(`INVERT`) ~ px(30),
      vars(`Statewide Numerator`) ~ px(100),
      vars(`Statewide Denominator`) ~ px(100),
      vars(`Statewide Result`) ~ px(100)
    ) %>%
    
    # Write out to png
    gtsave(paste0(wd,"/images/",figname,".html"))
}

create_cdm_table(cdm_table, "Access/Availability of Care", "cdm_access")
create_cdm_table(cdm_table, "Behavioral Health", "cdm_behavioral")
create_cdm_table(cdm_table, "Behavioral Health - Follow-Up", "cdm_behavioral_fu")
## create_cdm_table(cdm_table, "Diabetes", "cdm_diabetes")
create_cdm_table(cdm_table, "Pediatric Admission", "cdm_ped")
create_cdm_table(cdm_table, "Prevention and Screening", "cdm_prev")
create_cdm_table(cdm_table, "Respiratory Conditions", "cdm_resp")

write_appendix_M360(appendix, "8.1-8.5 - Quality Measures", cdm_table %>% arrange(`Measure Category`, `Measure Name`))

cat("\nSection 8 Complete")

{% if debug==False %}

},
error = function(e){message("ERROR:", e)}
#warning = function(w){message("WARNING:", w)}
)
{% endif %}

#####################################################################
### WRITE APPENDIX TO EXCEL
saveWorkbook(appendix, file=paste0("output/M360_Appendix_{{report_name}}.xlsx"), overwrite = T)
# saveWorkbook(appendix, file="m360_appendix_test.xlsx")

cat("\nViews Built\n\n\n")
