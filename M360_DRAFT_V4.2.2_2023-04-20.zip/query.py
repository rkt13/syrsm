import jinja2
import os
import pandas as pd
import pyodbc

def get_connection(username, password, host, port, database):

    return pyodbc.connect(
        "DRIVER={Vertica};"
        f"SERVER={host};"
        f"PORT={port};"
        f"DATABASE={database};"
        f"UID={username};"
        "PWD={" + password + "};"
    )

def query_db(conn, query, fetch=True, context=None):
    # Function for querying
    # Will search in queries/ director for profiles to load (ignores file extensions)
    # and either run a matching query file (template) OR the query string directly
    
    
    # Check against templates available
    templatefile = None
    for s in os.listdir('queries'):
        if os.path.splitext(s)[0] == os.path.splitext(query)[0] and os.path.isfile(os.path.join('queries', s)):
            templatefile = os.path.basename(s)
            break
    
    # If template exists, load and render with
    # context variables
    if templatefile is not None:
        query = render_template(templatefile, context)
      
    # Execute query and withdraw result
    c = conn.cursor()
    c.execute(query)
    result = None
    if fetch:
        records = c.fetchall()
        columns = [x[0] for x in c.description]
        result = pd.DataFrame.from_records(records, columns = columns)
        
    c.close()
    return result


def render_template(filename, context = None, searchpath='./queries'):
    '''
    Renders a template `filename` with the loaded `context` dictionary
    by default this function searches in `queries` relative to the base
    M360_GUI.py path
    '''


    tLoader = jinja2.FileSystemLoader(searchpath=searchpath)
    tEnv = jinja2.Environment(loader=tLoader)

    template = tEnv.get_template(filename)

    if context is None:
        context = {}

    query = template.render(**context)

    return query


def load_queries_into_context(context = None, searchpath='./queries', context_prefix='QRY'):
    '''
    Loads all queries as strings into a consolidated context
    dictionary in the specified `searchpath`. Optionally pre-renders
    the queries with the given context (required for two-stage loading)
    '''

    queries = {}
    for queryfile in os.listdir(searchpath):

        nosuffix = os.path.splitext(queryfile)[0]
        nosuffix = nosuffix.upper()

        queries['_'.join([context_prefix, nosuffix])] = render_template(queryfile, context, searchpath)

    return queries
