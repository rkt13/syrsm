import base64
import csv
import os
import re
import subprocess
import sys
import pandas as pd
import json
import jinja2

from query import render_template

def load_config(path):
    '''Loads graphics configuration file to layout images/tables as specified'''

    fields = ['secind', 'figind', 'section', 'row', 'title', 'path', 'width', 'height', 'caption', 'br']

    with open(path, 'rt', encoding='utf-8') as f:

        data = json.load(f)

    return data

def subset_config(config, sections):
    # This function subsets the lines of the config file we imported to only leave specific views from the GUI
    sub_config = []
    for row in config:
        if row['secind'] in sections:
            sub_config.append(row)
    return sub_config

def b64_encode_image(path, extension='png'):
    '''Convert graphic to b64encoded version for HTML embedding'''

    with open(path, 'rb') as f:
        data = f.read()

    encoded = base64.b64encode(data)

    uri = f'data:image/{extension};base64,{encoded.decode()}'

    return uri


def get_between(string, start, end):

        s, e = string.find(start), string.find(end)
        return string[s+len(start):e]


def parse_gtable(path):

    with open(path, 'rt', encoding = 'utf-8') as f:

        raw_html = f.read()

    body = get_between(raw_html, '<body>','</body>')
    style = get_between(body, '<style>', '</style>')
    table = get_between(body, '<div', '</div>')

    return {'style': style, 'table': table}


def generate_report(
    cohort_name, 
    cohort_description, 
    comparison_description, 
    time_period, 
    report_name, 
    dual_label,
    included_sections
    ):

    full_layout_config = load_config('graphics_config.json')
    layout_config = subset_config(full_layout_config, included_sections)
    logo = b64_encode_image('assets/logo.jpg','jpeg')

    # Create the nested structure...
    # Section -> Row -> Figure(s)
    sections = {}
    section_order = []
    gtable_styles = []

    for element in layout_config:

        section = element['section']
        row = element['row']
        title =  element['title']
        path = element['path']
        width = element['width']
        height = element['height']
        caption = element['caption']
        br = element['br']

        if not os.path.exists(path):
            continue

        if not (section in sections):
            section_no = len(section_order)
            section_order.append(section)
            sections[section] = {}
            sections[section]['section_name'] = section
            sections[section]['page_break'] = section_no != 0
            sections[section]['row_count'] = 0
            sections[section]['graphic_count'] = 0
            sections[section]['row_order'] = []
            sections[section]['rows'] = {}
        
        sections[section]['graphic_count'] += 1

        if not (row in sections[section]['rows']):
            sections[section]['rows'][row] = []
            sections[section]['row_order'].append(row)

        if path[-5:] == '.html':
            figtype = 'table'
            _ = parse_gtable(path)
            figdata = _['table']
            gtable_styles.append(_['style'])
        else:
            figtype = 'image'
            figdata = b64_encode_image(path)

        sections[section]['rows'][row].append({
            'figure_title': title,
            'figure_source': path,
            'figure_type': figtype,
            'figure_data': figdata,
            'width': width,
            'height': height,
            'figure_caption': caption if caption != '' else None,
            'page_break': br != '' and len(sections[section]['row_order']) > 1
        })

    # List'ify the data structure
    data_for_template = []

    for s_ix in section_order:
        s = sections[s_ix]

        rows = []
        
        for r_ix in s['row_order']:
            if len(s['rows'][r_ix]) == 1:
                s['rows'][r_ix][0]['pos'] = 'C'
            else:
                s['rows'][r_ix][0]['pos'] = 'L'
                s['rows'][r_ix][1]['pos'] = 'R'

            rows.append(s['rows'][r_ix])

        data_for_template.append({
            'section_name': s['section_name'],
            'rows': rows,
            'page_break': s['page_break']
        })

    with open('output/M360_Report_' + report_name + '.html','wt',encoding='utf-8') as f:
        f.write(
            render_template(
                'base.html',
                context = {
                    'title': 'Member360 Report',
                    'cohort_name': cohort_name,
                    'date_range': time_period,
                    'cohort_description': cohort_description,
                    'comparison_description': comparison_description,
                    'logo': logo,
                    'sections': data_for_template,
                    'gtable_styles': '\n'.join(gtable_styles),
                    'dual_label': dual_label,
                },
                searchpath = './template'
            )
        )

    with open('template/m360_header.render.html', 'wt') as f:
        f.write(
            render_template(
                'm360_header.html',
                context = {'cohort_name': cohort_name, 'dual_label': dual_label},
                searchpath = './template'
            )
        )

    WK_EXE = r'assets/wkhtmltopdf.exe'
    subprocess.run([
        WK_EXE,
        '--page-size','letter',
        '--enable-local-file-access',
        '--disable-smart-shrinking',
        '--dpi','300',
        '--zoom','0.9',
        '--print-media-type',
        '-T','0.25in',
        '-B','0.25in',
        '-L','0.5in',
        '-R','0.25in',
        '--header-html', './template/m360_header.render.html',
        f'output/M360_Report_{report_name}.html',
        f'output/M360_Report_{report_name}.pdf'
    ],
    stdout=subprocess.DEVNULL,
    stderr=subprocess.DEVNULL
    )
    
    os.unlink('template/m360_header.render.html')
